//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Thu Mar 26 01:14:28 2026
//Host        : Justin-T480 running 64-bit major release  (build 9200)
//Command     : generate_target CPU_wrapper.bd
//Design      : CPU_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module CPU_wrapper
   (ALURes,
    clk,
    reset);
  output [15:0]ALURes;
  input clk;
  input reset;

  wire [15:0]ALURes;
  wire clk;
  wire reset;

  CPU CPU_i
       (.ALURes(ALURes),
        .clk(clk),
        .reset(reset));
endmodule
