-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:58:51 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_Multiplexer_3_0/CPU_Multiplexer_3_0_sim_netlist.vhdl
-- Design      : CPU_Multiplexer_3_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_Multiplexer_3_0_Multiplexer is
  port (
    \out\ : out STD_LOGIC_VECTOR ( 15 downto 0 );
    input1 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    input0 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    \select\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_Multiplexer_3_0_Multiplexer : entity is "Multiplexer";
end CPU_Multiplexer_3_0_Multiplexer;

architecture STRUCTURE of CPU_Multiplexer_3_0_Multiplexer is
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \out[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \out[10]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \out[11]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \out[12]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \out[13]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \out[14]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \out[15]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \out[1]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \out[2]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \out[3]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \out[4]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \out[5]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \out[6]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \out[7]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \out[8]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \out[9]_INST_0\ : label is "soft_lutpair4";
begin
\out[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(0),
      I1 => input0(0),
      I2 => \select\,
      O => \out\(0)
    );
\out[10]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(10),
      I1 => input0(10),
      I2 => \select\,
      O => \out\(10)
    );
\out[11]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(11),
      I1 => input0(11),
      I2 => \select\,
      O => \out\(11)
    );
\out[12]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(12),
      I1 => input0(12),
      I2 => \select\,
      O => \out\(12)
    );
\out[13]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(13),
      I1 => input0(13),
      I2 => \select\,
      O => \out\(13)
    );
\out[14]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(14),
      I1 => input0(14),
      I2 => \select\,
      O => \out\(14)
    );
\out[15]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(15),
      I1 => input0(15),
      I2 => \select\,
      O => \out\(15)
    );
\out[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(1),
      I1 => input0(1),
      I2 => \select\,
      O => \out\(1)
    );
\out[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(2),
      I1 => input0(2),
      I2 => \select\,
      O => \out\(2)
    );
\out[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(3),
      I1 => input0(3),
      I2 => \select\,
      O => \out\(3)
    );
\out[4]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(4),
      I1 => input0(4),
      I2 => \select\,
      O => \out\(4)
    );
\out[5]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(5),
      I1 => input0(5),
      I2 => \select\,
      O => \out\(5)
    );
\out[6]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(6),
      I1 => input0(6),
      I2 => \select\,
      O => \out\(6)
    );
\out[7]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(7),
      I1 => input0(7),
      I2 => \select\,
      O => \out\(7)
    );
\out[8]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(8),
      I1 => input0(8),
      I2 => \select\,
      O => \out\(8)
    );
\out[9]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => input1(9),
      I1 => input0(9),
      I2 => \select\,
      O => \out\(9)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_Multiplexer_3_0 is
  port (
    input0 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    input1 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    \select\ : in STD_LOGIC;
    \out\ : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_Multiplexer_3_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_Multiplexer_3_0 : entity is "CPU_Multiplexer_3_0,Multiplexer,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_Multiplexer_3_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_Multiplexer_3_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_Multiplexer_3_0 : entity is "Multiplexer,Vivado 2025.2";
end CPU_Multiplexer_3_0;

architecture STRUCTURE of CPU_Multiplexer_3_0 is
begin
inst: entity work.CPU_Multiplexer_3_0_Multiplexer
     port map (
      input0(15 downto 0) => input0(15 downto 0),
      input1(15 downto 0) => input1(15 downto 0),
      \out\(15 downto 0) => \out\(15 downto 0),
      \select\ => \select\
    );
end STRUCTURE;
