// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:58:42 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_PCRegister_0_0/CPU_PCRegister_0_0_sim_netlist.v
// Design      : CPU_PCRegister_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CPU_PCRegister_0_0,PCRegister,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "PCRegister,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module CPU_PCRegister_0_0
   (clk,
    reset,
    pc_in,
    pc_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN CPU_clk, INSERT_VIP 0" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 reset RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input reset;
  input [15:0]pc_in;
  output [15:0]pc_out;

  wire clk;
  wire [15:0]pc_in;
  wire [15:0]pc_out;
  wire reset;

  CPU_PCRegister_0_0_PCRegister inst
       (.clk(clk),
        .pc_in(pc_in),
        .pc_out(pc_out),
        .reset(reset));
endmodule

(* ORIG_REF_NAME = "PCRegister" *) 
module CPU_PCRegister_0_0_PCRegister
   (pc_out,
    reset,
    pc_in,
    clk);
  output [15:0]pc_out;
  input reset;
  input [15:0]pc_in;
  input clk;

  wire clk;
  wire [15:0]pc_in;
  wire [15:0]pc_out;
  wire reset;

  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[0]),
        .Q(pc_out[0]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[10]),
        .Q(pc_out[10]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[11]),
        .Q(pc_out[11]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[12]),
        .Q(pc_out[12]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[13]),
        .Q(pc_out[13]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[14]),
        .Q(pc_out[14]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[15]),
        .Q(pc_out[15]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[1]),
        .Q(pc_out[1]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[2]),
        .Q(pc_out[2]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[3]),
        .Q(pc_out[3]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[4]),
        .Q(pc_out[4]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[5]),
        .Q(pc_out[5]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[6]),
        .Q(pc_out[6]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[7]),
        .Q(pc_out[7]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[8]),
        .Q(pc_out[8]),
        .R(reset));
  FDRE #(
    .INIT(1'b0)) 
    \pc_out_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(pc_in[9]),
        .Q(pc_out[9]),
        .R(reset));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
