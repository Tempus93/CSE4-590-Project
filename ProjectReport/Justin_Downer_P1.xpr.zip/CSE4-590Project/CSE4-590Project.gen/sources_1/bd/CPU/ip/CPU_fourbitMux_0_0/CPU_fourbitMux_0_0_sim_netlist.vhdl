-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Mon Mar 23 19:47:47 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_fourbitMux_0_0/CPU_fourbitMux_0_0_sim_netlist.vhdl
-- Design      : CPU_fourbitMux_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_fourbitMux_0_0_fourbitMux is
  port (
    \out\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    input1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \select\ : in STD_LOGIC;
    input0 : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_fourbitMux_0_0_fourbitMux : entity is "fourbitMux";
end CPU_fourbitMux_0_0_fourbitMux;

architecture STRUCTURE of CPU_fourbitMux_0_0_fourbitMux is
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \out[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \out[1]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \out[2]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \out[3]_INST_0\ : label is "soft_lutpair1";
begin
\out[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => input1(0),
      I1 => \select\,
      I2 => input0(0),
      O => \out\(0)
    );
\out[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => input1(1),
      I1 => \select\,
      I2 => input0(1),
      O => \out\(1)
    );
\out[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => input1(2),
      I1 => \select\,
      I2 => input0(2),
      O => \out\(2)
    );
\out[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => input1(3),
      I1 => \select\,
      I2 => input0(3),
      O => \out\(3)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_fourbitMux_0_0 is
  port (
    input0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    input1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \select\ : in STD_LOGIC;
    \out\ : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_fourbitMux_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_fourbitMux_0_0 : entity is "CPU_fourbitMux_0_0,fourbitMux,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_fourbitMux_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_fourbitMux_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_fourbitMux_0_0 : entity is "fourbitMux,Vivado 2025.2";
end CPU_fourbitMux_0_0;

architecture STRUCTURE of CPU_fourbitMux_0_0 is
begin
inst: entity work.CPU_fourbitMux_0_0_fourbitMux
     port map (
      input0(3 downto 0) => input0(3 downto 0),
      input1(3 downto 0) => input1(3 downto 0),
      \out\(3 downto 0) => \out\(3 downto 0),
      \select\ => \select\
    );
end STRUCTURE;
