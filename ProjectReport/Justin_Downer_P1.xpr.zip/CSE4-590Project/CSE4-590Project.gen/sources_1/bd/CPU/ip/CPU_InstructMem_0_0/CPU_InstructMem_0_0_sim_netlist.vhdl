-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:56:45 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_InstructMem_0_0/CPU_InstructMem_0_0_sim_netlist.vhdl
-- Design      : CPU_InstructMem_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_InstructMem_0_0 is
  port (
    Address : in STD_LOGIC_VECTOR ( 15 downto 0 );
    Instruction : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_InstructMem_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_InstructMem_0_0 : entity is "CPU_InstructMem_0_0,InstructMem,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_InstructMem_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_InstructMem_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_InstructMem_0_0 : entity is "InstructMem,Vivado 2025.2";
end CPU_InstructMem_0_0;

architecture STRUCTURE of CPU_InstructMem_0_0 is
  signal \<const0>\ : STD_LOGIC;
begin
  Instruction(15) <= \<const0>\;
  Instruction(14) <= \<const0>\;
  Instruction(13) <= \<const0>\;
  Instruction(12) <= \<const0>\;
  Instruction(11) <= \<const0>\;
  Instruction(10) <= \<const0>\;
  Instruction(9) <= \<const0>\;
  Instruction(8) <= \<const0>\;
  Instruction(7) <= \<const0>\;
  Instruction(6) <= \<const0>\;
  Instruction(5) <= \<const0>\;
  Instruction(4) <= \<const0>\;
  Instruction(3) <= \<const0>\;
  Instruction(2) <= \<const0>\;
  Instruction(1) <= \<const0>\;
  Instruction(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
end STRUCTURE;
