-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:58:51 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_PCAdder_0_0/CPU_PCAdder_0_0_sim_netlist.vhdl
-- Design      : CPU_PCAdder_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_PCAdder_0_0_PCAdder is
  port (
    pc_next : out STD_LOGIC_VECTOR ( 15 downto 0 );
    pc_branch : out STD_LOGIC_VECTOR ( 15 downto 0 );
    imm_shifted : in STD_LOGIC_VECTOR ( 15 downto 0 );
    pc_in : in STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_PCAdder_0_0_PCAdder : entity is "PCAdder";
end CPU_PCAdder_0_0_PCAdder;

architecture STRUCTURE of CPU_PCAdder_0_0_PCAdder is
  signal \pc_branch_carry__0_n_0\ : STD_LOGIC;
  signal \pc_branch_carry__0_n_1\ : STD_LOGIC;
  signal \pc_branch_carry__0_n_2\ : STD_LOGIC;
  signal \pc_branch_carry__0_n_3\ : STD_LOGIC;
  signal \pc_branch_carry__1_n_0\ : STD_LOGIC;
  signal \pc_branch_carry__1_n_1\ : STD_LOGIC;
  signal \pc_branch_carry__1_n_2\ : STD_LOGIC;
  signal \pc_branch_carry__1_n_3\ : STD_LOGIC;
  signal \pc_branch_carry__2_n_1\ : STD_LOGIC;
  signal \pc_branch_carry__2_n_2\ : STD_LOGIC;
  signal \pc_branch_carry__2_n_3\ : STD_LOGIC;
  signal \pc_branch_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_1__2_n_0\ : STD_LOGIC;
  signal pc_branch_carry_i_1_n_0 : STD_LOGIC;
  signal \pc_branch_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_2__2_n_0\ : STD_LOGIC;
  signal pc_branch_carry_i_2_n_0 : STD_LOGIC;
  signal \pc_branch_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_3__2_n_0\ : STD_LOGIC;
  signal pc_branch_carry_i_3_n_0 : STD_LOGIC;
  signal \pc_branch_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \pc_branch_carry_i_4__2_n_0\ : STD_LOGIC;
  signal pc_branch_carry_i_4_n_0 : STD_LOGIC;
  signal pc_branch_carry_n_0 : STD_LOGIC;
  signal pc_branch_carry_n_1 : STD_LOGIC;
  signal pc_branch_carry_n_2 : STD_LOGIC;
  signal pc_branch_carry_n_3 : STD_LOGIC;
  signal \^pc_next\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \pc_next_carry__0_n_0\ : STD_LOGIC;
  signal \pc_next_carry__0_n_1\ : STD_LOGIC;
  signal \pc_next_carry__0_n_2\ : STD_LOGIC;
  signal \pc_next_carry__0_n_3\ : STD_LOGIC;
  signal \pc_next_carry__1_n_0\ : STD_LOGIC;
  signal \pc_next_carry__1_n_1\ : STD_LOGIC;
  signal \pc_next_carry__1_n_2\ : STD_LOGIC;
  signal \pc_next_carry__1_n_3\ : STD_LOGIC;
  signal \pc_next_carry__2_n_1\ : STD_LOGIC;
  signal \pc_next_carry__2_n_2\ : STD_LOGIC;
  signal \pc_next_carry__2_n_3\ : STD_LOGIC;
  signal pc_next_carry_i_1_n_0 : STD_LOGIC;
  signal pc_next_carry_n_0 : STD_LOGIC;
  signal pc_next_carry_n_1 : STD_LOGIC;
  signal pc_next_carry_n_2 : STD_LOGIC;
  signal pc_next_carry_n_3 : STD_LOGIC;
  signal \NLW_pc_branch_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_pc_next_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of pc_branch_carry : label is 35;
  attribute ADDER_THRESHOLD of \pc_branch_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \pc_branch_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \pc_branch_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of pc_next_carry : label is 35;
  attribute ADDER_THRESHOLD of \pc_next_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \pc_next_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \pc_next_carry__2\ : label is 35;
begin
  pc_next(15 downto 0) <= \^pc_next\(15 downto 0);
pc_branch_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pc_branch_carry_n_0,
      CO(2) => pc_branch_carry_n_1,
      CO(1) => pc_branch_carry_n_2,
      CO(0) => pc_branch_carry_n_3,
      CYINIT => '0',
      DI(3 downto 0) => \^pc_next\(3 downto 0),
      O(3 downto 0) => pc_branch(3 downto 0),
      S(3) => pc_branch_carry_i_1_n_0,
      S(2) => pc_branch_carry_i_2_n_0,
      S(1) => pc_branch_carry_i_3_n_0,
      S(0) => pc_branch_carry_i_4_n_0
    );
\pc_branch_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => pc_branch_carry_n_0,
      CO(3) => \pc_branch_carry__0_n_0\,
      CO(2) => \pc_branch_carry__0_n_1\,
      CO(1) => \pc_branch_carry__0_n_2\,
      CO(0) => \pc_branch_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^pc_next\(7 downto 4),
      O(3 downto 0) => pc_branch(7 downto 4),
      S(3) => \pc_branch_carry_i_1__0_n_0\,
      S(2) => \pc_branch_carry_i_2__0_n_0\,
      S(1) => \pc_branch_carry_i_3__0_n_0\,
      S(0) => \pc_branch_carry_i_4__0_n_0\
    );
\pc_branch_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \pc_branch_carry__0_n_0\,
      CO(3) => \pc_branch_carry__1_n_0\,
      CO(2) => \pc_branch_carry__1_n_1\,
      CO(1) => \pc_branch_carry__1_n_2\,
      CO(0) => \pc_branch_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^pc_next\(11 downto 8),
      O(3 downto 0) => pc_branch(11 downto 8),
      S(3) => \pc_branch_carry_i_1__1_n_0\,
      S(2) => \pc_branch_carry_i_2__1_n_0\,
      S(1) => \pc_branch_carry_i_3__1_n_0\,
      S(0) => \pc_branch_carry_i_4__1_n_0\
    );
\pc_branch_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \pc_branch_carry__1_n_0\,
      CO(3) => \NLW_pc_branch_carry__2_CO_UNCONNECTED\(3),
      CO(2) => \pc_branch_carry__2_n_1\,
      CO(1) => \pc_branch_carry__2_n_2\,
      CO(0) => \pc_branch_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => \^pc_next\(14 downto 12),
      O(3 downto 0) => pc_branch(15 downto 12),
      S(3) => \pc_branch_carry_i_1__2_n_0\,
      S(2) => \pc_branch_carry_i_2__2_n_0\,
      S(1) => \pc_branch_carry_i_3__2_n_0\,
      S(0) => \pc_branch_carry_i_4__2_n_0\
    );
pc_branch_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(3),
      I1 => imm_shifted(3),
      O => pc_branch_carry_i_1_n_0
    );
\pc_branch_carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(7),
      I1 => imm_shifted(7),
      O => \pc_branch_carry_i_1__0_n_0\
    );
\pc_branch_carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(11),
      I1 => imm_shifted(11),
      O => \pc_branch_carry_i_1__1_n_0\
    );
\pc_branch_carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(15),
      I1 => imm_shifted(15),
      O => \pc_branch_carry_i_1__2_n_0\
    );
pc_branch_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(2),
      I1 => imm_shifted(2),
      O => pc_branch_carry_i_2_n_0
    );
\pc_branch_carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(6),
      I1 => imm_shifted(6),
      O => \pc_branch_carry_i_2__0_n_0\
    );
\pc_branch_carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(10),
      I1 => imm_shifted(10),
      O => \pc_branch_carry_i_2__1_n_0\
    );
\pc_branch_carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(14),
      I1 => imm_shifted(14),
      O => \pc_branch_carry_i_2__2_n_0\
    );
pc_branch_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(1),
      I1 => imm_shifted(1),
      O => pc_branch_carry_i_3_n_0
    );
\pc_branch_carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(5),
      I1 => imm_shifted(5),
      O => \pc_branch_carry_i_3__0_n_0\
    );
\pc_branch_carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(9),
      I1 => imm_shifted(9),
      O => \pc_branch_carry_i_3__1_n_0\
    );
\pc_branch_carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(13),
      I1 => imm_shifted(13),
      O => \pc_branch_carry_i_3__2_n_0\
    );
pc_branch_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(0),
      I1 => imm_shifted(0),
      O => pc_branch_carry_i_4_n_0
    );
\pc_branch_carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(4),
      I1 => imm_shifted(4),
      O => \pc_branch_carry_i_4__0_n_0\
    );
\pc_branch_carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(8),
      I1 => imm_shifted(8),
      O => \pc_branch_carry_i_4__1_n_0\
    );
\pc_branch_carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^pc_next\(12),
      I1 => imm_shifted(12),
      O => \pc_branch_carry_i_4__2_n_0\
    );
pc_next_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pc_next_carry_n_0,
      CO(2) => pc_next_carry_n_1,
      CO(1) => pc_next_carry_n_2,
      CO(0) => pc_next_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => pc_in(1),
      DI(0) => '0',
      O(3 downto 0) => \^pc_next\(3 downto 0),
      S(3 downto 2) => pc_in(3 downto 2),
      S(1) => pc_next_carry_i_1_n_0,
      S(0) => pc_in(0)
    );
\pc_next_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => pc_next_carry_n_0,
      CO(3) => \pc_next_carry__0_n_0\,
      CO(2) => \pc_next_carry__0_n_1\,
      CO(1) => \pc_next_carry__0_n_2\,
      CO(0) => \pc_next_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \^pc_next\(7 downto 4),
      S(3 downto 0) => pc_in(7 downto 4)
    );
\pc_next_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \pc_next_carry__0_n_0\,
      CO(3) => \pc_next_carry__1_n_0\,
      CO(2) => \pc_next_carry__1_n_1\,
      CO(1) => \pc_next_carry__1_n_2\,
      CO(0) => \pc_next_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \^pc_next\(11 downto 8),
      S(3 downto 0) => pc_in(11 downto 8)
    );
\pc_next_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \pc_next_carry__1_n_0\,
      CO(3) => \NLW_pc_next_carry__2_CO_UNCONNECTED\(3),
      CO(2) => \pc_next_carry__2_n_1\,
      CO(1) => \pc_next_carry__2_n_2\,
      CO(0) => \pc_next_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \^pc_next\(15 downto 12),
      S(3 downto 0) => pc_in(15 downto 12)
    );
pc_next_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pc_in(1),
      O => pc_next_carry_i_1_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_PCAdder_0_0 is
  port (
    pc_in : in STD_LOGIC_VECTOR ( 15 downto 0 );
    imm_shifted : in STD_LOGIC_VECTOR ( 15 downto 0 );
    pc_next : out STD_LOGIC_VECTOR ( 15 downto 0 );
    pc_branch : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_PCAdder_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_PCAdder_0_0 : entity is "CPU_PCAdder_0_0,PCAdder,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_PCAdder_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_PCAdder_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_PCAdder_0_0 : entity is "PCAdder,Vivado 2025.2";
end CPU_PCAdder_0_0;

architecture STRUCTURE of CPU_PCAdder_0_0 is
begin
inst: entity work.CPU_PCAdder_0_0_PCAdder
     port map (
      imm_shifted(15 downto 0) => imm_shifted(15 downto 0),
      pc_branch(15 downto 0) => pc_branch(15 downto 0),
      pc_in(15 downto 0) => pc_in(15 downto 0),
      pc_next(15 downto 0) => pc_next(15 downto 0)
    );
end STRUCTURE;
