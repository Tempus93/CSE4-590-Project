// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:ALU:1.0
// IP Revision: 1

(* X_CORE_INFO = "ALU,Vivado 2025.2" *)
(* CHECK_LICENSE_TYPE = "CPU_ALU_0_0,ALU,{}" *)
(* CORE_GENERATION_INFO = "CPU_ALU_0_0,ALU,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=ALU,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,ADD=000,SUB=001,SLL=010,AND=011,LW=0001,SW=0010,BEQ=0100,BNE=0101,JMP=0110}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module CPU_ALU_0_0 (
  ReadData1,
  ReadData2,
  ALUControl,
  zero,
  ALUResult
);

input wire [15 : 0] ReadData1;
input wire [15 : 0] ReadData2;
input wire [3 : 0] ALUControl;
output wire zero;
output wire [15 : 0] ALUResult;

  ALU #(
    .ADD(3'B000),
    .SUB(3'B001),
    .SLL(3'B010),
    .AND(3'B011),
    .LW(4'B0001),
    .SW(4'B0010),
    .BEQ(4'B0100),
    .BNE(4'B0101),
    .JMP(4'B0110)
  ) inst (
    .ReadData1(ReadData1),
    .ReadData2(ReadData2),
    .ALUControl(ALUControl),
    .zero(zero),
    .ALUResult(ALUResult)
  );
endmodule
