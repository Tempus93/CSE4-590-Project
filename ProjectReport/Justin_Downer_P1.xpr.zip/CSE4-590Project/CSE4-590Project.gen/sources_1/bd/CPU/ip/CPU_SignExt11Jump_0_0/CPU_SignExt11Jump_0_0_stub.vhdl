-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:50:45 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_SignExt11Jump_0_0/CPU_SignExt11Jump_0_0_stub.vhdl
-- Design      : CPU_SignExt11Jump_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity CPU_SignExt11Jump_0_0 is
  Port ( 
    imm_value : in STD_LOGIC_VECTOR ( 11 downto 0 );
    result : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_SignExt11Jump_0_0 : entity is "CPU_SignExt11Jump_0_0,SignExt11Jump,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of CPU_SignExt11Jump_0_0 : entity is "CPU_SignExt11Jump_0_0,SignExt11Jump,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=SignExt11Jump,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_SignExt11Jump_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_SignExt11Jump_0_0 : entity is "module_ref";
end CPU_SignExt11Jump_0_0;

architecture stub of CPU_SignExt11Jump_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "imm_value[11:0],result[15:0]";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "SignExt11Jump,Vivado 2025.2";
begin
end;
