// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:56:25 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_ControlUnit_0_0/CPU_ControlUnit_0_0_stub.v
// Design      : CPU_ControlUnit_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "CPU_ControlUnit_0_0,ControlUnit,{}" *) (* CORE_GENERATION_INFO = "CPU_ControlUnit_0_0,ControlUnit,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=ControlUnit,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "ControlUnit,Vivado 2025.2" *) 
module CPU_ControlUnit_0_0(Instruction, RegDst, ALUSrc, MemtoReg, RegWrite, 
  MemRead, MemWrite, Branch, BNE, Jump, ALUOp)
/* synthesis syn_black_box black_box_pad_pin="Instruction[3:0],RegDst,ALUSrc,MemtoReg,RegWrite,MemRead,MemWrite,Branch,BNE,Jump,ALUOp[1:0]" */;
  input [3:0]Instruction;
  output RegDst;
  output ALUSrc;
  output MemtoReg;
  output RegWrite;
  output MemRead;
  output MemWrite;
  output Branch;
  output BNE;
  output Jump;
  output [1:0]ALUOp;
endmodule
