// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:50:47 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_ALU_0_0/CPU_ALU_0_0_sim_netlist.v
// Design      : CPU_ALU_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CPU_ALU_0_0,ALU,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "ALU,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module CPU_ALU_0_0
   (ReadData1,
    ReadData2,
    ALUControl,
    zero,
    ALUResult);
  input [15:0]ReadData1;
  input [15:0]ReadData2;
  input [3:0]ALUControl;
  output zero;
  output [15:0]ALUResult;

  wire [3:0]ALUControl;
  wire [15:0]ALUResult;
  wire [15:0]ReadData1;
  wire [15:0]ReadData2;
  wire zero;

  CPU_ALU_0_0_ALU inst
       (.ALUControl(ALUControl),
        .ALUResult(ALUResult),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2),
        .zero(zero));
endmodule

(* ORIG_REF_NAME = "ALU" *) 
module CPU_ALU_0_0_ALU
   (zero,
    ALUResult,
    ReadData2,
    ALUControl,
    ReadData1);
  output zero;
  output [15:0]ALUResult;
  input [15:0]ReadData2;
  input [3:0]ALUControl;
  input [15:0]ReadData1;

  wire [3:0]ALUControl;
  wire [15:0]ALUResult;
  wire [15:0]ALUResult01_in;
  wire [15:0]ALUResult02_in;
  wire \ALUResult0_inferred__1/i__carry__0_n_0 ;
  wire \ALUResult0_inferred__1/i__carry__0_n_1 ;
  wire \ALUResult0_inferred__1/i__carry__0_n_2 ;
  wire \ALUResult0_inferred__1/i__carry__0_n_3 ;
  wire \ALUResult0_inferred__1/i__carry__1_n_0 ;
  wire \ALUResult0_inferred__1/i__carry__1_n_1 ;
  wire \ALUResult0_inferred__1/i__carry__1_n_2 ;
  wire \ALUResult0_inferred__1/i__carry__1_n_3 ;
  wire \ALUResult0_inferred__1/i__carry__2_n_1 ;
  wire \ALUResult0_inferred__1/i__carry__2_n_2 ;
  wire \ALUResult0_inferred__1/i__carry__2_n_3 ;
  wire \ALUResult0_inferred__1/i__carry_n_0 ;
  wire \ALUResult0_inferred__1/i__carry_n_1 ;
  wire \ALUResult0_inferred__1/i__carry_n_2 ;
  wire \ALUResult0_inferred__1/i__carry_n_3 ;
  wire \ALUResult0_inferred__2/i__carry__0_n_0 ;
  wire \ALUResult0_inferred__2/i__carry__0_n_1 ;
  wire \ALUResult0_inferred__2/i__carry__0_n_2 ;
  wire \ALUResult0_inferred__2/i__carry__0_n_3 ;
  wire \ALUResult0_inferred__2/i__carry__1_n_0 ;
  wire \ALUResult0_inferred__2/i__carry__1_n_1 ;
  wire \ALUResult0_inferred__2/i__carry__1_n_2 ;
  wire \ALUResult0_inferred__2/i__carry__1_n_3 ;
  wire \ALUResult0_inferred__2/i__carry__2_n_1 ;
  wire \ALUResult0_inferred__2/i__carry__2_n_2 ;
  wire \ALUResult0_inferred__2/i__carry__2_n_3 ;
  wire \ALUResult0_inferred__2/i__carry_n_0 ;
  wire \ALUResult0_inferred__2/i__carry_n_1 ;
  wire \ALUResult0_inferred__2/i__carry_n_2 ;
  wire \ALUResult0_inferred__2/i__carry_n_3 ;
  wire \ALUResult[0]_INST_0_i_1_n_0 ;
  wire \ALUResult[10]_INST_0_i_1_n_0 ;
  wire \ALUResult[10]_INST_0_i_2_n_0 ;
  wire \ALUResult[11]_INST_0_i_1_n_0 ;
  wire \ALUResult[11]_INST_0_i_2_n_0 ;
  wire \ALUResult[11]_INST_0_i_3_n_0 ;
  wire \ALUResult[12]_INST_0_i_1_n_0 ;
  wire \ALUResult[12]_INST_0_i_2_n_0 ;
  wire \ALUResult[12]_INST_0_i_3_n_0 ;
  wire \ALUResult[13]_INST_0_i_1_n_0 ;
  wire \ALUResult[13]_INST_0_i_2_n_0 ;
  wire \ALUResult[13]_INST_0_i_3_n_0 ;
  wire \ALUResult[14]_INST_0_i_10_n_0 ;
  wire \ALUResult[14]_INST_0_i_1_n_0 ;
  wire \ALUResult[14]_INST_0_i_2_n_0 ;
  wire \ALUResult[14]_INST_0_i_3_n_0 ;
  wire \ALUResult[14]_INST_0_i_4_n_0 ;
  wire \ALUResult[14]_INST_0_i_5_n_0 ;
  wire \ALUResult[14]_INST_0_i_6_n_0 ;
  wire \ALUResult[14]_INST_0_i_7_n_0 ;
  wire \ALUResult[14]_INST_0_i_8_n_0 ;
  wire \ALUResult[14]_INST_0_i_9_n_0 ;
  wire \ALUResult[15]_INST_0_i_1_n_0 ;
  wire \ALUResult[15]_INST_0_i_2_n_0 ;
  wire \ALUResult[15]_INST_0_i_3_n_0 ;
  wire \ALUResult[15]_INST_0_i_4_n_0 ;
  wire \ALUResult[1]_INST_0_i_1_n_0 ;
  wire \ALUResult[1]_INST_0_i_2_n_0 ;
  wire \ALUResult[2]_INST_0_i_1_n_0 ;
  wire \ALUResult[2]_INST_0_i_2_n_0 ;
  wire \ALUResult[3]_INST_0_i_1_n_0 ;
  wire \ALUResult[3]_INST_0_i_2_n_0 ;
  wire \ALUResult[4]_INST_0_i_1_n_0 ;
  wire \ALUResult[4]_INST_0_i_2_n_0 ;
  wire \ALUResult[5]_INST_0_i_1_n_0 ;
  wire \ALUResult[5]_INST_0_i_2_n_0 ;
  wire \ALUResult[6]_INST_0_i_1_n_0 ;
  wire \ALUResult[6]_INST_0_i_2_n_0 ;
  wire \ALUResult[7]_INST_0_i_1_n_0 ;
  wire \ALUResult[7]_INST_0_i_2_n_0 ;
  wire \ALUResult[7]_INST_0_i_3_n_0 ;
  wire \ALUResult[8]_INST_0_i_1_n_0 ;
  wire \ALUResult[8]_INST_0_i_2_n_0 ;
  wire \ALUResult[8]_INST_0_i_3_n_0 ;
  wire \ALUResult[9]_INST_0_i_1_n_0 ;
  wire \ALUResult[9]_INST_0_i_2_n_0 ;
  wire [15:0]ReadData1;
  wire [15:0]ReadData2;
  wire i__carry__0_i_1_n_0;
  wire i__carry__0_i_2_n_0;
  wire i__carry__0_i_3_n_0;
  wire i__carry__0_i_4_n_0;
  wire i__carry__1_i_1_n_0;
  wire i__carry__1_i_2_n_0;
  wire i__carry__1_i_3_n_0;
  wire i__carry__1_i_4_n_0;
  wire i__carry__2_i_1_n_0;
  wire i__carry__2_i_2_n_0;
  wire i__carry__2_i_3_n_0;
  wire i__carry__2_i_4_n_0;
  wire i__carry_i_1__0_n_0;
  wire i__carry_i_1__1_n_0;
  wire i__carry_i_1__2_n_0;
  wire i__carry_i_1__3_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2__0_n_0;
  wire i__carry_i_2__1_n_0;
  wire i__carry_i_2__2_n_0;
  wire i__carry_i_2__3_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3__0_n_0;
  wire i__carry_i_3__1_n_0;
  wire i__carry_i_3__2_n_0;
  wire i__carry_i_3__3_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_4__0_n_0;
  wire i__carry_i_4__1_n_0;
  wire i__carry_i_4__2_n_0;
  wire i__carry_i_4__3_n_0;
  wire i__carry_i_4_n_0;
  wire zero;
  wire zero_INST_0_i_1_n_0;
  wire zero_INST_0_i_2_n_0;
  wire zero_INST_0_i_3_n_0;
  wire [3:3]\NLW_ALUResult0_inferred__1/i__carry__2_CO_UNCONNECTED ;
  wire [3:3]\NLW_ALUResult0_inferred__2/i__carry__2_CO_UNCONNECTED ;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__1/i__carry 
       (.CI(1'b0),
        .CO({\ALUResult0_inferred__1/i__carry_n_0 ,\ALUResult0_inferred__1/i__carry_n_1 ,\ALUResult0_inferred__1/i__carry_n_2 ,\ALUResult0_inferred__1/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI(ReadData1[3:0]),
        .O(ALUResult01_in[3:0]),
        .S({i__carry_i_1__3_n_0,i__carry_i_2__3_n_0,i__carry_i_3__3_n_0,i__carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__1/i__carry__0 
       (.CI(\ALUResult0_inferred__1/i__carry_n_0 ),
        .CO({\ALUResult0_inferred__1/i__carry__0_n_0 ,\ALUResult0_inferred__1/i__carry__0_n_1 ,\ALUResult0_inferred__1/i__carry__0_n_2 ,\ALUResult0_inferred__1/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI(ReadData1[7:4]),
        .O(ALUResult01_in[7:4]),
        .S({i__carry__0_i_1_n_0,i__carry__0_i_2_n_0,i__carry__0_i_3_n_0,i__carry__0_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__1/i__carry__1 
       (.CI(\ALUResult0_inferred__1/i__carry__0_n_0 ),
        .CO({\ALUResult0_inferred__1/i__carry__1_n_0 ,\ALUResult0_inferred__1/i__carry__1_n_1 ,\ALUResult0_inferred__1/i__carry__1_n_2 ,\ALUResult0_inferred__1/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI(ReadData1[11:8]),
        .O(ALUResult01_in[11:8]),
        .S({i__carry__1_i_1_n_0,i__carry__1_i_2_n_0,i__carry__1_i_3_n_0,i__carry__1_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__1/i__carry__2 
       (.CI(\ALUResult0_inferred__1/i__carry__1_n_0 ),
        .CO({\NLW_ALUResult0_inferred__1/i__carry__2_CO_UNCONNECTED [3],\ALUResult0_inferred__1/i__carry__2_n_1 ,\ALUResult0_inferred__1/i__carry__2_n_2 ,\ALUResult0_inferred__1/i__carry__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,ReadData1[14:12]}),
        .O(ALUResult01_in[15:12]),
        .S({i__carry__2_i_1_n_0,i__carry__2_i_2_n_0,i__carry__2_i_3_n_0,i__carry__2_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__2/i__carry 
       (.CI(1'b0),
        .CO({\ALUResult0_inferred__2/i__carry_n_0 ,\ALUResult0_inferred__2/i__carry_n_1 ,\ALUResult0_inferred__2/i__carry_n_2 ,\ALUResult0_inferred__2/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI(ReadData1[3:0]),
        .O(ALUResult02_in[3:0]),
        .S({i__carry_i_1__2_n_0,i__carry_i_2__2_n_0,i__carry_i_3__2_n_0,i__carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__2/i__carry__0 
       (.CI(\ALUResult0_inferred__2/i__carry_n_0 ),
        .CO({\ALUResult0_inferred__2/i__carry__0_n_0 ,\ALUResult0_inferred__2/i__carry__0_n_1 ,\ALUResult0_inferred__2/i__carry__0_n_2 ,\ALUResult0_inferred__2/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI(ReadData1[7:4]),
        .O(ALUResult02_in[7:4]),
        .S({i__carry_i_1__1_n_0,i__carry_i_2__1_n_0,i__carry_i_3__1_n_0,i__carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__2/i__carry__1 
       (.CI(\ALUResult0_inferred__2/i__carry__0_n_0 ),
        .CO({\ALUResult0_inferred__2/i__carry__1_n_0 ,\ALUResult0_inferred__2/i__carry__1_n_1 ,\ALUResult0_inferred__2/i__carry__1_n_2 ,\ALUResult0_inferred__2/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI(ReadData1[11:8]),
        .O(ALUResult02_in[11:8]),
        .S({i__carry_i_1__0_n_0,i__carry_i_2__0_n_0,i__carry_i_3__0_n_0,i__carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ALUResult0_inferred__2/i__carry__2 
       (.CI(\ALUResult0_inferred__2/i__carry__1_n_0 ),
        .CO({\NLW_ALUResult0_inferred__2/i__carry__2_CO_UNCONNECTED [3],\ALUResult0_inferred__2/i__carry__2_n_1 ,\ALUResult0_inferred__2/i__carry__2_n_2 ,\ALUResult0_inferred__2/i__carry__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,ReadData1[14:12]}),
        .O(ALUResult02_in[15:12]),
        .S({i__carry_i_1_n_0,i__carry_i_2_n_0,i__carry_i_3_n_0,i__carry_i_4_n_0}));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h10111010)) 
    \ALUResult[0]_INST_0 
       (.I0(ALUControl[3]),
        .I1(ALUControl[2]),
        .I2(\ALUResult[0]_INST_0_i_1_n_0 ),
        .I3(\ALUResult[1]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_6_n_0 ),
        .O(ALUResult[0]));
  LUT6 #(
    .INIT(64'hF000CCCC0000AAAA)) 
    \ALUResult[0]_INST_0_i_1 
       (.I0(ALUResult02_in[0]),
        .I1(ALUResult01_in[0]),
        .I2(ReadData2[0]),
        .I3(ReadData1[0]),
        .I4(ALUControl[1]),
        .I5(ALUControl[0]),
        .O(\ALUResult[0]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA80AA80AA80)) 
    \ALUResult[10]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I2(\ALUResult[10]_INST_0_i_1_n_0 ),
        .I3(\ALUResult[10]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I5(\ALUResult[11]_INST_0_i_2_n_0 ),
        .O(ALUResult[10]));
  LUT6 #(
    .INIT(64'h00B8FFFF00B80000)) 
    \ALUResult[10]_INST_0_i_1 
       (.I0(ReadData1[3]),
        .I1(ReadData2[2]),
        .I2(ReadData1[7]),
        .I3(ReadData2[3]),
        .I4(ReadData2[1]),
        .I5(\ALUResult[12]_INST_0_i_3_n_0 ),
        .O(\ALUResult[10]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[10]_INST_0_i_2 
       (.I0(ReadData2[10]),
        .I1(ReadData1[10]),
        .I2(ALUResult01_in[10]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[10]),
        .O(\ALUResult[10]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA80AA80AA80)) 
    \ALUResult[11]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I2(\ALUResult[12]_INST_0_i_1_n_0 ),
        .I3(\ALUResult[11]_INST_0_i_1_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[11]_INST_0_i_2_n_0 ),
        .O(ALUResult[11]));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[11]_INST_0_i_1 
       (.I0(ReadData2[11]),
        .I1(ReadData1[11]),
        .I2(ALUResult01_in[11]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[11]),
        .O(\ALUResult[11]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \ALUResult[11]_INST_0_i_2 
       (.I0(\ALUResult[11]_INST_0_i_3_n_0 ),
        .I1(ReadData2[1]),
        .I2(\ALUResult[13]_INST_0_i_3_n_0 ),
        .O(\ALUResult[11]_INST_0_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ALUResult[11]_INST_0_i_3 
       (.I0(ReadData1[4]),
        .I1(ReadData2[2]),
        .I2(ReadData1[0]),
        .I3(ReadData2[3]),
        .I4(ReadData1[8]),
        .O(\ALUResult[11]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA80AA80AA80)) 
    \ALUResult[12]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I2(\ALUResult[12]_INST_0_i_1_n_0 ),
        .I3(\ALUResult[12]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I5(\ALUResult[13]_INST_0_i_2_n_0 ),
        .O(ALUResult[12]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \ALUResult[12]_INST_0_i_1 
       (.I0(\ALUResult[12]_INST_0_i_3_n_0 ),
        .I1(ReadData2[1]),
        .I2(\ALUResult[14]_INST_0_i_7_n_0 ),
        .O(\ALUResult[12]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[12]_INST_0_i_2 
       (.I0(ReadData2[12]),
        .I1(ReadData1[12]),
        .I2(ALUResult01_in[12]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[12]),
        .O(\ALUResult[12]_INST_0_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ALUResult[12]_INST_0_i_3 
       (.I0(ReadData1[5]),
        .I1(ReadData2[2]),
        .I2(ReadData1[1]),
        .I3(ReadData2[3]),
        .I4(ReadData1[9]),
        .O(\ALUResult[12]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA80AA80AA80)) 
    \ALUResult[13]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_3_n_0 ),
        .I3(\ALUResult[13]_INST_0_i_1_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[13]_INST_0_i_2_n_0 ),
        .O(ALUResult[13]));
  LUT6 #(
    .INIT(64'h8800FFF0880000F0)) 
    \ALUResult[13]_INST_0_i_1 
       (.I0(ReadData2[13]),
        .I1(ReadData1[13]),
        .I2(ALUResult02_in[13]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult01_in[13]),
        .O(\ALUResult[13]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \ALUResult[13]_INST_0_i_2 
       (.I0(\ALUResult[13]_INST_0_i_3_n_0 ),
        .I1(ReadData2[1]),
        .I2(\ALUResult[14]_INST_0_i_9_n_0 ),
        .O(\ALUResult[13]_INST_0_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ALUResult[13]_INST_0_i_3 
       (.I0(ReadData1[6]),
        .I1(ReadData2[2]),
        .I2(ReadData1[2]),
        .I3(ReadData2[3]),
        .I4(ReadData1[10]),
        .O(\ALUResult[13]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA80AA80AA80)) 
    \ALUResult[14]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_3_n_0 ),
        .I3(\ALUResult[14]_INST_0_i_4_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_5_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_6_n_0 ),
        .O(ALUResult[14]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \ALUResult[14]_INST_0_i_1 
       (.I0(ALUControl[2]),
        .I1(ALUControl[3]),
        .O(\ALUResult[14]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ALUResult[14]_INST_0_i_10 
       (.I0(ReadData1[2]),
        .I1(ReadData1[10]),
        .I2(ReadData2[2]),
        .I3(ReadData1[6]),
        .I4(ReadData2[3]),
        .I5(ReadData1[14]),
        .O(\ALUResult[14]_INST_0_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \ALUResult[14]_INST_0_i_2 
       (.I0(ReadData2[0]),
        .I1(ALUControl[1]),
        .I2(ALUControl[0]),
        .O(\ALUResult[14]_INST_0_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \ALUResult[14]_INST_0_i_3 
       (.I0(\ALUResult[14]_INST_0_i_7_n_0 ),
        .I1(ReadData2[1]),
        .I2(\ALUResult[14]_INST_0_i_8_n_0 ),
        .O(\ALUResult[14]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[14]_INST_0_i_4 
       (.I0(ReadData2[14]),
        .I1(ReadData1[14]),
        .I2(ALUResult01_in[14]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[14]),
        .O(\ALUResult[14]_INST_0_i_4_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \ALUResult[14]_INST_0_i_5 
       (.I0(\ALUResult[14]_INST_0_i_9_n_0 ),
        .I1(ReadData2[1]),
        .I2(\ALUResult[14]_INST_0_i_10_n_0 ),
        .O(\ALUResult[14]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \ALUResult[14]_INST_0_i_6 
       (.I0(ReadData2[0]),
        .I1(ALUControl[1]),
        .I2(ALUControl[0]),
        .O(\ALUResult[14]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ALUResult[14]_INST_0_i_7 
       (.I0(ReadData1[7]),
        .I1(ReadData2[2]),
        .I2(ReadData1[3]),
        .I3(ReadData2[3]),
        .I4(ReadData1[11]),
        .O(\ALUResult[14]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ALUResult[14]_INST_0_i_8 
       (.I0(ReadData1[1]),
        .I1(ReadData1[9]),
        .I2(ReadData2[2]),
        .I3(ReadData1[5]),
        .I4(ReadData2[3]),
        .I5(ReadData1[13]),
        .O(\ALUResult[14]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ALUResult[14]_INST_0_i_9 
       (.I0(ReadData1[0]),
        .I1(ReadData1[8]),
        .I2(ReadData2[2]),
        .I3(ReadData1[4]),
        .I4(ReadData2[3]),
        .I5(ReadData1[12]),
        .O(\ALUResult[14]_INST_0_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \ALUResult[15]_INST_0 
       (.I0(\ALUResult[15]_INST_0_i_1_n_0 ),
        .O(ALUResult[15]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF0111)) 
    \ALUResult[15]_INST_0_i_1 
       (.I0(\ALUResult[15]_INST_0_i_2_n_0 ),
        .I1(\ALUResult[15]_INST_0_i_3_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_5_n_0 ),
        .I3(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I4(ALUControl[3]),
        .I5(ALUControl[2]),
        .O(\ALUResult[15]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0404040000040000)) 
    \ALUResult[15]_INST_0_i_2 
       (.I0(ALUControl[0]),
        .I1(ALUControl[1]),
        .I2(ReadData2[0]),
        .I3(ReadData2[1]),
        .I4(\ALUResult[15]_INST_0_i_4_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_8_n_0 ),
        .O(\ALUResult[15]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0CA00CA00CA00CA)) 
    \ALUResult[15]_INST_0_i_3 
       (.I0(ALUResult02_in[15]),
        .I1(ALUResult01_in[15]),
        .I2(ALUControl[0]),
        .I3(ALUControl[1]),
        .I4(ReadData2[15]),
        .I5(ReadData1[15]),
        .O(\ALUResult[15]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ALUResult[15]_INST_0_i_4 
       (.I0(ReadData1[3]),
        .I1(ReadData1[11]),
        .I2(ReadData2[2]),
        .I3(ReadData1[7]),
        .I4(ReadData2[3]),
        .I5(ReadData1[15]),
        .O(\ALUResult[15]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h8A88AAAA8A888A88)) 
    \ALUResult[1]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[1]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[2]_INST_0_i_1_n_0 ),
        .I3(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I4(\ALUResult[1]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_2_n_0 ),
        .O(ALUResult[1]));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[1]_INST_0_i_1 
       (.I0(ReadData2[1]),
        .I1(ReadData1[1]),
        .I2(ALUResult01_in[1]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[1]),
        .O(\ALUResult[1]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hFFEF)) 
    \ALUResult[1]_INST_0_i_2 
       (.I0(ReadData2[1]),
        .I1(ReadData2[3]),
        .I2(ReadData1[0]),
        .I3(ReadData2[2]),
        .O(\ALUResult[1]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \ALUResult[2]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[2]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I3(\ALUResult[2]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[3]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_6_n_0 ),
        .O(ALUResult[2]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFFEF)) 
    \ALUResult[2]_INST_0_i_1 
       (.I0(ReadData2[1]),
        .I1(ReadData2[3]),
        .I2(ReadData1[1]),
        .I3(ReadData2[2]),
        .O(\ALUResult[2]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[2]_INST_0_i_2 
       (.I0(ReadData2[2]),
        .I1(ReadData1[2]),
        .I2(ALUResult01_in[2]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[2]),
        .O(\ALUResult[2]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \ALUResult[3]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[4]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I3(\ALUResult[3]_INST_0_i_1_n_0 ),
        .I4(\ALUResult[3]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_2_n_0 ),
        .O(ALUResult[3]));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[3]_INST_0_i_1 
       (.I0(ReadData2[3]),
        .I1(ReadData1[3]),
        .I2(ALUResult01_in[3]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[3]),
        .O(\ALUResult[3]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hFFFFF4F7)) 
    \ALUResult[3]_INST_0_i_2 
       (.I0(ReadData1[0]),
        .I1(ReadData2[1]),
        .I2(ReadData2[2]),
        .I3(ReadData1[2]),
        .I4(ReadData2[3]),
        .O(\ALUResult[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \ALUResult[4]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[4]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I3(\ALUResult[4]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[5]_INST_0_i_1_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_6_n_0 ),
        .O(ALUResult[4]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hFFFFF4F7)) 
    \ALUResult[4]_INST_0_i_1 
       (.I0(ReadData1[1]),
        .I1(ReadData2[1]),
        .I2(ReadData2[2]),
        .I3(ReadData1[3]),
        .I4(ReadData2[3]),
        .O(\ALUResult[4]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[4]_INST_0_i_2 
       (.I0(ReadData2[4]),
        .I1(ReadData1[4]),
        .I2(ALUResult01_in[4]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[4]),
        .O(\ALUResult[4]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \ALUResult[5]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[5]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I3(\ALUResult[5]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[6]_INST_0_i_1_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_6_n_0 ),
        .O(ALUResult[5]));
  LUT6 #(
    .INIT(64'hFFFFCF44FFFFCF77)) 
    \ALUResult[5]_INST_0_i_1 
       (.I0(ReadData1[2]),
        .I1(ReadData2[1]),
        .I2(ReadData1[0]),
        .I3(ReadData2[2]),
        .I4(ReadData2[3]),
        .I5(ReadData1[4]),
        .O(\ALUResult[5]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[5]_INST_0_i_2 
       (.I0(ReadData2[5]),
        .I1(ReadData1[5]),
        .I2(ALUResult01_in[5]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[5]),
        .O(\ALUResult[5]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \ALUResult[6]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[6]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I3(\ALUResult[6]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[7]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_6_n_0 ),
        .O(ALUResult[6]));
  LUT6 #(
    .INIT(64'hFFFFFFFFCF44CF77)) 
    \ALUResult[6]_INST_0_i_1 
       (.I0(ReadData1[3]),
        .I1(ReadData2[1]),
        .I2(ReadData1[1]),
        .I3(ReadData2[2]),
        .I4(ReadData1[5]),
        .I5(ReadData2[3]),
        .O(\ALUResult[6]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[6]_INST_0_i_2 
       (.I0(ReadData2[6]),
        .I1(ReadData1[6]),
        .I2(ALUResult01_in[6]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[6]),
        .O(\ALUResult[6]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAA20AAAAAA20AA20)) 
    \ALUResult[7]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[8]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I3(\ALUResult[7]_INST_0_i_1_n_0 ),
        .I4(\ALUResult[7]_INST_0_i_2_n_0 ),
        .I5(\ALUResult[14]_INST_0_i_2_n_0 ),
        .O(ALUResult[7]));
  LUT6 #(
    .INIT(64'h8800FFF0880000F0)) 
    \ALUResult[7]_INST_0_i_1 
       (.I0(ReadData2[7]),
        .I1(ReadData1[7]),
        .I2(ALUResult02_in[7]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult01_in[7]),
        .O(\ALUResult[7]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF4F70000F4F7FFFF)) 
    \ALUResult[7]_INST_0_i_2 
       (.I0(ReadData1[0]),
        .I1(ReadData2[2]),
        .I2(ReadData2[3]),
        .I3(ReadData1[4]),
        .I4(ReadData2[1]),
        .I5(\ALUResult[7]_INST_0_i_3_n_0 ),
        .O(\ALUResult[7]_INST_0_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h00E2)) 
    \ALUResult[7]_INST_0_i_3 
       (.I0(ReadData1[6]),
        .I1(ReadData2[2]),
        .I2(ReadData1[2]),
        .I3(ReadData2[3]),
        .O(\ALUResult[7]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA20AA20AA20)) 
    \ALUResult[8]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[8]_INST_0_i_1_n_0 ),
        .I2(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I3(\ALUResult[8]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I5(\ALUResult[9]_INST_0_i_1_n_0 ),
        .O(ALUResult[8]));
  LUT6 #(
    .INIT(64'hFF47FFFFFF470000)) 
    \ALUResult[8]_INST_0_i_1 
       (.I0(ReadData1[1]),
        .I1(ReadData2[2]),
        .I2(ReadData1[5]),
        .I3(ReadData2[3]),
        .I4(ReadData2[1]),
        .I5(\ALUResult[8]_INST_0_i_3_n_0 ),
        .O(\ALUResult[8]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800F0FF8800F000)) 
    \ALUResult[8]_INST_0_i_2 
       (.I0(ReadData2[8]),
        .I1(ReadData1[8]),
        .I2(ALUResult01_in[8]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult02_in[8]),
        .O(\ALUResult[8]_INST_0_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hFF47)) 
    \ALUResult[8]_INST_0_i_3 
       (.I0(ReadData1[3]),
        .I1(ReadData2[2]),
        .I2(ReadData1[7]),
        .I3(ReadData2[3]),
        .O(\ALUResult[8]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA80AA80AA80)) 
    \ALUResult[9]_INST_0 
       (.I0(\ALUResult[14]_INST_0_i_1_n_0 ),
        .I1(\ALUResult[14]_INST_0_i_2_n_0 ),
        .I2(\ALUResult[9]_INST_0_i_1_n_0 ),
        .I3(\ALUResult[9]_INST_0_i_2_n_0 ),
        .I4(\ALUResult[14]_INST_0_i_6_n_0 ),
        .I5(\ALUResult[10]_INST_0_i_1_n_0 ),
        .O(ALUResult[9]));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ALUResult[9]_INST_0_i_1 
       (.I0(ReadData1[6]),
        .I1(ReadData2[2]),
        .I2(ReadData1[2]),
        .I3(ReadData2[3]),
        .I4(ReadData2[1]),
        .I5(\ALUResult[11]_INST_0_i_3_n_0 ),
        .O(\ALUResult[9]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8800FFF0880000F0)) 
    \ALUResult[9]_INST_0_i_2 
       (.I0(ReadData2[9]),
        .I1(ReadData1[9]),
        .I2(ALUResult02_in[9]),
        .I3(ALUControl[0]),
        .I4(ALUControl[1]),
        .I5(ALUResult01_in[9]),
        .O(\ALUResult[9]_INST_0_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_1
       (.I0(ReadData1[7]),
        .I1(ReadData2[7]),
        .O(i__carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_2
       (.I0(ReadData1[6]),
        .I1(ReadData2[6]),
        .O(i__carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_3
       (.I0(ReadData1[5]),
        .I1(ReadData2[5]),
        .O(i__carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__0_i_4
       (.I0(ReadData1[4]),
        .I1(ReadData2[4]),
        .O(i__carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__1_i_1
       (.I0(ReadData1[11]),
        .I1(ReadData2[11]),
        .O(i__carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__1_i_2
       (.I0(ReadData1[10]),
        .I1(ReadData2[10]),
        .O(i__carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__1_i_3
       (.I0(ReadData1[9]),
        .I1(ReadData2[9]),
        .O(i__carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__1_i_4
       (.I0(ReadData1[8]),
        .I1(ReadData2[8]),
        .O(i__carry__1_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__2_i_1
       (.I0(ReadData2[15]),
        .I1(ReadData1[15]),
        .O(i__carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__2_i_2
       (.I0(ReadData1[14]),
        .I1(ReadData2[14]),
        .O(i__carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__2_i_3
       (.I0(ReadData1[13]),
        .I1(ReadData2[13]),
        .O(i__carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__2_i_4
       (.I0(ReadData1[12]),
        .I1(ReadData2[12]),
        .O(i__carry__2_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_1
       (.I0(ReadData1[15]),
        .I1(ReadData2[15]),
        .O(i__carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_1__0
       (.I0(ReadData2[11]),
        .I1(ReadData1[11]),
        .O(i__carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_1__1
       (.I0(ReadData2[7]),
        .I1(ReadData1[7]),
        .O(i__carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_1__2
       (.I0(ReadData2[3]),
        .I1(ReadData1[3]),
        .O(i__carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_1__3
       (.I0(ReadData1[3]),
        .I1(ReadData2[3]),
        .O(i__carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_2
       (.I0(ReadData2[14]),
        .I1(ReadData1[14]),
        .O(i__carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_2__0
       (.I0(ReadData2[10]),
        .I1(ReadData1[10]),
        .O(i__carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_2__1
       (.I0(ReadData2[6]),
        .I1(ReadData1[6]),
        .O(i__carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_2__2
       (.I0(ReadData2[2]),
        .I1(ReadData1[2]),
        .O(i__carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_2__3
       (.I0(ReadData1[2]),
        .I1(ReadData2[2]),
        .O(i__carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_3
       (.I0(ReadData2[13]),
        .I1(ReadData1[13]),
        .O(i__carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_3__0
       (.I0(ReadData2[9]),
        .I1(ReadData1[9]),
        .O(i__carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_3__1
       (.I0(ReadData2[5]),
        .I1(ReadData1[5]),
        .O(i__carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_3__2
       (.I0(ReadData2[1]),
        .I1(ReadData1[1]),
        .O(i__carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_3__3
       (.I0(ReadData1[1]),
        .I1(ReadData2[1]),
        .O(i__carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_4
       (.I0(ReadData2[12]),
        .I1(ReadData1[12]),
        .O(i__carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_4__0
       (.I0(ReadData2[8]),
        .I1(ReadData1[8]),
        .O(i__carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_4__1
       (.I0(ReadData2[4]),
        .I1(ReadData1[4]),
        .O(i__carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_4__2
       (.I0(ReadData2[0]),
        .I1(ReadData1[0]),
        .O(i__carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_4__3
       (.I0(ReadData1[0]),
        .I1(ReadData2[0]),
        .O(i__carry_i_4__3_n_0));
  LUT5 #(
    .INIT(32'h00000002)) 
    zero_INST_0
       (.I0(zero_INST_0_i_1_n_0),
        .I1(zero_INST_0_i_2_n_0),
        .I2(ALUResult[12]),
        .I3(ALUResult[14]),
        .I4(zero_INST_0_i_3_n_0),
        .O(zero));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h0004)) 
    zero_INST_0_i_1
       (.I0(ALUResult[11]),
        .I1(\ALUResult[15]_INST_0_i_1_n_0 ),
        .I2(ALUResult[9]),
        .I3(ALUResult[13]),
        .O(zero_INST_0_i_1_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    zero_INST_0_i_2
       (.I0(ALUResult[10]),
        .I1(ALUResult[4]),
        .I2(ALUResult[3]),
        .I3(ALUResult[1]),
        .I4(ALUResult[0]),
        .I5(ALUResult[2]),
        .O(zero_INST_0_i_2_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    zero_INST_0_i_3
       (.I0(ALUResult[5]),
        .I1(ALUResult[7]),
        .I2(ALUResult[6]),
        .I3(ALUResult[8]),
        .O(zero_INST_0_i_3_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
