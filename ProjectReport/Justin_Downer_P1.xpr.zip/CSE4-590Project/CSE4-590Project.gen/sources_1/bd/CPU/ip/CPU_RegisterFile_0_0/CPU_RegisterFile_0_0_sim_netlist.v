// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:56:49 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_RegisterFile_0_0/CPU_RegisterFile_0_0_sim_netlist.v
// Design      : CPU_RegisterFile_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CPU_RegisterFile_0_0,RegisterFile,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "RegisterFile,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module CPU_RegisterFile_0_0
   (clk,
    read_reg1,
    read_reg2,
    write_reg,
    write_data,
    reg_write,
    read_data1,
    read_data2);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN CPU_clk, INSERT_VIP 0" *) input clk;
  input [3:0]read_reg1;
  input [3:0]read_reg2;
  input [3:0]write_reg;
  input [15:0]write_data;
  input reg_write;
  output [15:0]read_data1;
  output [15:0]read_data2;

  wire clk;
  wire [15:0]read_data1;
  wire [15:0]read_data2;
  wire [3:0]read_reg1;
  wire [3:0]read_reg2;
  wire reg_write;
  wire [15:0]write_data;
  wire [3:0]write_reg;

  CPU_RegisterFile_0_0_RegisterFile inst
       (.clk(clk),
        .read_data1(read_data1),
        .read_data2(read_data2),
        .read_reg1(read_reg1),
        .read_reg2(read_reg2),
        .reg_write(reg_write),
        .write_data(write_data),
        .write_reg(write_reg));
endmodule

(* ORIG_REF_NAME = "RegisterFile" *) 
module CPU_RegisterFile_0_0_RegisterFile
   (read_data1,
    read_data2,
    clk,
    reg_write,
    write_data,
    read_reg1,
    write_reg,
    read_reg2);
  output [15:0]read_data1;
  output [15:0]read_data2;
  input clk;
  input reg_write;
  input [15:0]write_data;
  input [3:0]read_reg1;
  input [3:0]write_reg;
  input [3:0]read_reg2;

  wire clk;
  wire [15:0]read_data1;
  wire [15:0]read_data2;
  wire [3:0]read_reg1;
  wire [3:0]read_reg2;
  wire reg_write;
  wire [15:0]write_data;
  wire [3:0]write_reg;
  wire [1:0]NLW_registers_reg_r1_0_15_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r1_0_15_12_15_DOC_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r1_0_15_12_15_DOD_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r1_0_15_6_11_DOD_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r2_0_15_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r2_0_15_12_15_DOC_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r2_0_15_12_15_DOD_UNCONNECTED;
  wire [1:0]NLW_registers_reg_r2_0_15_6_11_DOD_UNCONNECTED;

  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "256" *) 
  (* RTL_RAM_NAME = "CPU_RegisterFile_0_0/inst/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "5" *) 
  RAM32M #(
    .INIT_A(64'h0000000000000024),
    .INIT_B(64'h0000000000000004),
    .INIT_C(64'h0000000000000000),
    .INIT_D(64'h0000000000000000)) 
    registers_reg_r1_0_15_0_5
       (.ADDRA({1'b0,read_reg1}),
        .ADDRB({1'b0,read_reg1}),
        .ADDRC({1'b0,read_reg1}),
        .ADDRD({1'b0,write_reg}),
        .DIA(write_data[1:0]),
        .DIB(write_data[3:2]),
        .DIC(write_data[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(read_data1[1:0]),
        .DOB(read_data1[3:2]),
        .DOC(read_data1[5:4]),
        .DOD(NLW_registers_reg_r1_0_15_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(reg_write));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "256" *) 
  (* RTL_RAM_NAME = "CPU_RegisterFile_0_0/inst/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "15" *) 
  RAM32M #(
    .INIT_A(64'h0000000000000000),
    .INIT_B(64'h0000000000000000),
    .INIT_C(64'h0000000000000000),
    .INIT_D(64'h0000000000000000)) 
    registers_reg_r1_0_15_12_15
       (.ADDRA({1'b0,read_reg1}),
        .ADDRB({1'b0,read_reg1}),
        .ADDRC({1'b0,read_reg1}),
        .ADDRD({1'b0,write_reg}),
        .DIA(write_data[13:12]),
        .DIB(write_data[15:14]),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(read_data1[13:12]),
        .DOB(read_data1[15:14]),
        .DOC(NLW_registers_reg_r1_0_15_12_15_DOC_UNCONNECTED[1:0]),
        .DOD(NLW_registers_reg_r1_0_15_12_15_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(reg_write));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "256" *) 
  (* RTL_RAM_NAME = "CPU_RegisterFile_0_0/inst/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "11" *) 
  RAM32M #(
    .INIT_A(64'h0000000000000000),
    .INIT_B(64'h0000000000000000),
    .INIT_C(64'h0000000000000000),
    .INIT_D(64'h0000000000000000)) 
    registers_reg_r1_0_15_6_11
       (.ADDRA({1'b0,read_reg1}),
        .ADDRB({1'b0,read_reg1}),
        .ADDRC({1'b0,read_reg1}),
        .ADDRD({1'b0,write_reg}),
        .DIA(write_data[7:6]),
        .DIB(write_data[9:8]),
        .DIC(write_data[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(read_data1[7:6]),
        .DOB(read_data1[9:8]),
        .DOC(read_data1[11:10]),
        .DOD(NLW_registers_reg_r1_0_15_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(reg_write));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "256" *) 
  (* RTL_RAM_NAME = "CPU_RegisterFile_0_0/inst/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "5" *) 
  RAM32M #(
    .INIT_A(64'h0000000000000024),
    .INIT_B(64'h0000000000000004),
    .INIT_C(64'h0000000000000000),
    .INIT_D(64'h0000000000000000)) 
    registers_reg_r2_0_15_0_5
       (.ADDRA({1'b0,read_reg2}),
        .ADDRB({1'b0,read_reg2}),
        .ADDRC({1'b0,read_reg2}),
        .ADDRD({1'b0,write_reg}),
        .DIA(write_data[1:0]),
        .DIB(write_data[3:2]),
        .DIC(write_data[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(read_data2[1:0]),
        .DOB(read_data2[3:2]),
        .DOC(read_data2[5:4]),
        .DOD(NLW_registers_reg_r2_0_15_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(reg_write));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "256" *) 
  (* RTL_RAM_NAME = "CPU_RegisterFile_0_0/inst/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "15" *) 
  RAM32M #(
    .INIT_A(64'h0000000000000000),
    .INIT_B(64'h0000000000000000),
    .INIT_C(64'h0000000000000000),
    .INIT_D(64'h0000000000000000)) 
    registers_reg_r2_0_15_12_15
       (.ADDRA({1'b0,read_reg2}),
        .ADDRB({1'b0,read_reg2}),
        .ADDRC({1'b0,read_reg2}),
        .ADDRD({1'b0,write_reg}),
        .DIA(write_data[13:12]),
        .DIB(write_data[15:14]),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(read_data2[13:12]),
        .DOB(read_data2[15:14]),
        .DOC(NLW_registers_reg_r2_0_15_12_15_DOC_UNCONNECTED[1:0]),
        .DOD(NLW_registers_reg_r2_0_15_12_15_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(reg_write));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "256" *) 
  (* RTL_RAM_NAME = "CPU_RegisterFile_0_0/inst/registers_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "15" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "11" *) 
  RAM32M #(
    .INIT_A(64'h0000000000000000),
    .INIT_B(64'h0000000000000000),
    .INIT_C(64'h0000000000000000),
    .INIT_D(64'h0000000000000000)) 
    registers_reg_r2_0_15_6_11
       (.ADDRA({1'b0,read_reg2}),
        .ADDRB({1'b0,read_reg2}),
        .ADDRC({1'b0,read_reg2}),
        .ADDRD({1'b0,write_reg}),
        .DIA(write_data[7:6]),
        .DIB(write_data[9:8]),
        .DIC(write_data[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(read_data2[7:6]),
        .DOB(read_data2[9:8]),
        .DOC(read_data2[11:10]),
        .DOD(NLW_registers_reg_r2_0_15_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(reg_write));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
