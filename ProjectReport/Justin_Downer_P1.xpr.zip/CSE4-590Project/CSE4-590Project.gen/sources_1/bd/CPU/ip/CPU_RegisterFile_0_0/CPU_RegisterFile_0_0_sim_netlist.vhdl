-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:56:49 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_RegisterFile_0_0/CPU_RegisterFile_0_0_sim_netlist.vhdl
-- Design      : CPU_RegisterFile_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_RegisterFile_0_0_RegisterFile is
  port (
    read_data1 : out STD_LOGIC_VECTOR ( 15 downto 0 );
    read_data2 : out STD_LOGIC_VECTOR ( 15 downto 0 );
    clk : in STD_LOGIC;
    reg_write : in STD_LOGIC;
    write_data : in STD_LOGIC_VECTOR ( 15 downto 0 );
    read_reg1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    write_reg : in STD_LOGIC_VECTOR ( 3 downto 0 );
    read_reg2 : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_RegisterFile_0_0_RegisterFile : entity is "RegisterFile";
end CPU_RegisterFile_0_0_RegisterFile;

architecture STRUCTURE of CPU_RegisterFile_0_0_RegisterFile is
  signal NLW_registers_reg_r1_0_15_0_5_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r1_0_15_12_15_DOC_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r1_0_15_12_15_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r1_0_15_6_11_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r2_0_15_0_5_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r2_0_15_12_15_DOC_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r2_0_15_12_15_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_registers_reg_r2_0_15_6_11_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of registers_reg_r1_0_15_0_5 : label is "";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of registers_reg_r1_0_15_0_5 : label is 256;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of registers_reg_r1_0_15_0_5 : label is "CPU_RegisterFile_0_0/inst/registers_reg";
  attribute RTL_RAM_STYLE : string;
  attribute RTL_RAM_STYLE of registers_reg_r1_0_15_0_5 : label is "auto";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of registers_reg_r1_0_15_0_5 : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of registers_reg_r1_0_15_0_5 : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of registers_reg_r1_0_15_0_5 : label is 15;
  attribute ram_offset : integer;
  attribute ram_offset of registers_reg_r1_0_15_0_5 : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of registers_reg_r1_0_15_0_5 : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of registers_reg_r1_0_15_0_5 : label is 5;
  attribute METHODOLOGY_DRC_VIOS of registers_reg_r1_0_15_12_15 : label is "";
  attribute RTL_RAM_BITS of registers_reg_r1_0_15_12_15 : label is 256;
  attribute RTL_RAM_NAME of registers_reg_r1_0_15_12_15 : label is "CPU_RegisterFile_0_0/inst/registers_reg";
  attribute RTL_RAM_STYLE of registers_reg_r1_0_15_12_15 : label is "auto";
  attribute RTL_RAM_TYPE of registers_reg_r1_0_15_12_15 : label is "RAM_SDP";
  attribute ram_addr_begin of registers_reg_r1_0_15_12_15 : label is 0;
  attribute ram_addr_end of registers_reg_r1_0_15_12_15 : label is 15;
  attribute ram_offset of registers_reg_r1_0_15_12_15 : label is 0;
  attribute ram_slice_begin of registers_reg_r1_0_15_12_15 : label is 12;
  attribute ram_slice_end of registers_reg_r1_0_15_12_15 : label is 15;
  attribute METHODOLOGY_DRC_VIOS of registers_reg_r1_0_15_6_11 : label is "";
  attribute RTL_RAM_BITS of registers_reg_r1_0_15_6_11 : label is 256;
  attribute RTL_RAM_NAME of registers_reg_r1_0_15_6_11 : label is "CPU_RegisterFile_0_0/inst/registers_reg";
  attribute RTL_RAM_STYLE of registers_reg_r1_0_15_6_11 : label is "auto";
  attribute RTL_RAM_TYPE of registers_reg_r1_0_15_6_11 : label is "RAM_SDP";
  attribute ram_addr_begin of registers_reg_r1_0_15_6_11 : label is 0;
  attribute ram_addr_end of registers_reg_r1_0_15_6_11 : label is 15;
  attribute ram_offset of registers_reg_r1_0_15_6_11 : label is 0;
  attribute ram_slice_begin of registers_reg_r1_0_15_6_11 : label is 6;
  attribute ram_slice_end of registers_reg_r1_0_15_6_11 : label is 11;
  attribute METHODOLOGY_DRC_VIOS of registers_reg_r2_0_15_0_5 : label is "";
  attribute RTL_RAM_BITS of registers_reg_r2_0_15_0_5 : label is 256;
  attribute RTL_RAM_NAME of registers_reg_r2_0_15_0_5 : label is "CPU_RegisterFile_0_0/inst/registers_reg";
  attribute RTL_RAM_STYLE of registers_reg_r2_0_15_0_5 : label is "auto";
  attribute RTL_RAM_TYPE of registers_reg_r2_0_15_0_5 : label is "RAM_SDP";
  attribute ram_addr_begin of registers_reg_r2_0_15_0_5 : label is 0;
  attribute ram_addr_end of registers_reg_r2_0_15_0_5 : label is 15;
  attribute ram_offset of registers_reg_r2_0_15_0_5 : label is 0;
  attribute ram_slice_begin of registers_reg_r2_0_15_0_5 : label is 0;
  attribute ram_slice_end of registers_reg_r2_0_15_0_5 : label is 5;
  attribute METHODOLOGY_DRC_VIOS of registers_reg_r2_0_15_12_15 : label is "";
  attribute RTL_RAM_BITS of registers_reg_r2_0_15_12_15 : label is 256;
  attribute RTL_RAM_NAME of registers_reg_r2_0_15_12_15 : label is "CPU_RegisterFile_0_0/inst/registers_reg";
  attribute RTL_RAM_STYLE of registers_reg_r2_0_15_12_15 : label is "auto";
  attribute RTL_RAM_TYPE of registers_reg_r2_0_15_12_15 : label is "RAM_SDP";
  attribute ram_addr_begin of registers_reg_r2_0_15_12_15 : label is 0;
  attribute ram_addr_end of registers_reg_r2_0_15_12_15 : label is 15;
  attribute ram_offset of registers_reg_r2_0_15_12_15 : label is 0;
  attribute ram_slice_begin of registers_reg_r2_0_15_12_15 : label is 12;
  attribute ram_slice_end of registers_reg_r2_0_15_12_15 : label is 15;
  attribute METHODOLOGY_DRC_VIOS of registers_reg_r2_0_15_6_11 : label is "";
  attribute RTL_RAM_BITS of registers_reg_r2_0_15_6_11 : label is 256;
  attribute RTL_RAM_NAME of registers_reg_r2_0_15_6_11 : label is "CPU_RegisterFile_0_0/inst/registers_reg";
  attribute RTL_RAM_STYLE of registers_reg_r2_0_15_6_11 : label is "auto";
  attribute RTL_RAM_TYPE of registers_reg_r2_0_15_6_11 : label is "RAM_SDP";
  attribute ram_addr_begin of registers_reg_r2_0_15_6_11 : label is 0;
  attribute ram_addr_end of registers_reg_r2_0_15_6_11 : label is 15;
  attribute ram_offset of registers_reg_r2_0_15_6_11 : label is 0;
  attribute ram_slice_begin of registers_reg_r2_0_15_6_11 : label is 6;
  attribute ram_slice_end of registers_reg_r2_0_15_6_11 : label is 11;
begin
registers_reg_r1_0_15_0_5: unisim.vcomponents.RAM32M
    generic map(
      INIT_A => X"0000000000000024",
      INIT_B => X"0000000000000004",
      INIT_C => X"0000000000000000",
      INIT_D => X"0000000000000000"
    )
        port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => read_reg1(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => read_reg1(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => read_reg1(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => write_reg(3 downto 0),
      DIA(1 downto 0) => write_data(1 downto 0),
      DIB(1 downto 0) => write_data(3 downto 2),
      DIC(1 downto 0) => write_data(5 downto 4),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => read_data1(1 downto 0),
      DOB(1 downto 0) => read_data1(3 downto 2),
      DOC(1 downto 0) => read_data1(5 downto 4),
      DOD(1 downto 0) => NLW_registers_reg_r1_0_15_0_5_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => reg_write
    );
registers_reg_r1_0_15_12_15: unisim.vcomponents.RAM32M
    generic map(
      INIT_A => X"0000000000000000",
      INIT_B => X"0000000000000000",
      INIT_C => X"0000000000000000",
      INIT_D => X"0000000000000000"
    )
        port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => read_reg1(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => read_reg1(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => read_reg1(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => write_reg(3 downto 0),
      DIA(1 downto 0) => write_data(13 downto 12),
      DIB(1 downto 0) => write_data(15 downto 14),
      DIC(1 downto 0) => B"00",
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => read_data1(13 downto 12),
      DOB(1 downto 0) => read_data1(15 downto 14),
      DOC(1 downto 0) => NLW_registers_reg_r1_0_15_12_15_DOC_UNCONNECTED(1 downto 0),
      DOD(1 downto 0) => NLW_registers_reg_r1_0_15_12_15_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => reg_write
    );
registers_reg_r1_0_15_6_11: unisim.vcomponents.RAM32M
    generic map(
      INIT_A => X"0000000000000000",
      INIT_B => X"0000000000000000",
      INIT_C => X"0000000000000000",
      INIT_D => X"0000000000000000"
    )
        port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => read_reg1(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => read_reg1(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => read_reg1(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => write_reg(3 downto 0),
      DIA(1 downto 0) => write_data(7 downto 6),
      DIB(1 downto 0) => write_data(9 downto 8),
      DIC(1 downto 0) => write_data(11 downto 10),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => read_data1(7 downto 6),
      DOB(1 downto 0) => read_data1(9 downto 8),
      DOC(1 downto 0) => read_data1(11 downto 10),
      DOD(1 downto 0) => NLW_registers_reg_r1_0_15_6_11_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => reg_write
    );
registers_reg_r2_0_15_0_5: unisim.vcomponents.RAM32M
    generic map(
      INIT_A => X"0000000000000024",
      INIT_B => X"0000000000000004",
      INIT_C => X"0000000000000000",
      INIT_D => X"0000000000000000"
    )
        port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => read_reg2(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => read_reg2(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => read_reg2(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => write_reg(3 downto 0),
      DIA(1 downto 0) => write_data(1 downto 0),
      DIB(1 downto 0) => write_data(3 downto 2),
      DIC(1 downto 0) => write_data(5 downto 4),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => read_data2(1 downto 0),
      DOB(1 downto 0) => read_data2(3 downto 2),
      DOC(1 downto 0) => read_data2(5 downto 4),
      DOD(1 downto 0) => NLW_registers_reg_r2_0_15_0_5_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => reg_write
    );
registers_reg_r2_0_15_12_15: unisim.vcomponents.RAM32M
    generic map(
      INIT_A => X"0000000000000000",
      INIT_B => X"0000000000000000",
      INIT_C => X"0000000000000000",
      INIT_D => X"0000000000000000"
    )
        port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => read_reg2(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => read_reg2(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => read_reg2(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => write_reg(3 downto 0),
      DIA(1 downto 0) => write_data(13 downto 12),
      DIB(1 downto 0) => write_data(15 downto 14),
      DIC(1 downto 0) => B"00",
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => read_data2(13 downto 12),
      DOB(1 downto 0) => read_data2(15 downto 14),
      DOC(1 downto 0) => NLW_registers_reg_r2_0_15_12_15_DOC_UNCONNECTED(1 downto 0),
      DOD(1 downto 0) => NLW_registers_reg_r2_0_15_12_15_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => reg_write
    );
registers_reg_r2_0_15_6_11: unisim.vcomponents.RAM32M
    generic map(
      INIT_A => X"0000000000000000",
      INIT_B => X"0000000000000000",
      INIT_C => X"0000000000000000",
      INIT_D => X"0000000000000000"
    )
        port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => read_reg2(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => read_reg2(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => read_reg2(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => write_reg(3 downto 0),
      DIA(1 downto 0) => write_data(7 downto 6),
      DIB(1 downto 0) => write_data(9 downto 8),
      DIC(1 downto 0) => write_data(11 downto 10),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => read_data2(7 downto 6),
      DOB(1 downto 0) => read_data2(9 downto 8),
      DOC(1 downto 0) => read_data2(11 downto 10),
      DOD(1 downto 0) => NLW_registers_reg_r2_0_15_6_11_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => reg_write
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_RegisterFile_0_0 is
  port (
    clk : in STD_LOGIC;
    read_reg1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    read_reg2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    write_reg : in STD_LOGIC_VECTOR ( 3 downto 0 );
    write_data : in STD_LOGIC_VECTOR ( 15 downto 0 );
    reg_write : in STD_LOGIC;
    read_data1 : out STD_LOGIC_VECTOR ( 15 downto 0 );
    read_data2 : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_RegisterFile_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_RegisterFile_0_0 : entity is "CPU_RegisterFile_0_0,RegisterFile,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_RegisterFile_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_RegisterFile_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_RegisterFile_0_0 : entity is "RegisterFile,Vivado 2025.2";
end CPU_RegisterFile_0_0;

architecture STRUCTURE of CPU_RegisterFile_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN CPU_clk, INSERT_VIP 0";
begin
inst: entity work.CPU_RegisterFile_0_0_RegisterFile
     port map (
      clk => clk,
      read_data1(15 downto 0) => read_data1(15 downto 0),
      read_data2(15 downto 0) => read_data2(15 downto 0),
      read_reg1(3 downto 0) => read_reg1(3 downto 0),
      read_reg2(3 downto 0) => read_reg2(3 downto 0),
      reg_write => reg_write,
      write_data(15 downto 0) => write_data(15 downto 0),
      write_reg(3 downto 0) => write_reg(3 downto 0)
    );
end STRUCTURE;
