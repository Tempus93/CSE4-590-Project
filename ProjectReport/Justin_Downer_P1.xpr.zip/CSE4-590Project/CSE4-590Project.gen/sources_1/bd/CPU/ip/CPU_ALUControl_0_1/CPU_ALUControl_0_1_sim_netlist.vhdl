-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Mon Mar 23 19:41:52 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_ALUControl_0_1/CPU_ALUControl_0_1_sim_netlist.vhdl
-- Design      : CPU_ALUControl_0_1
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_ALUControl_0_1_ALUControl is
  port (
    ALUControl : out STD_LOGIC_VECTOR ( 1 downto 0 );
    ALUOp : in STD_LOGIC_VECTOR ( 1 downto 0 );
    Instruction : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_ALUControl_0_1_ALUControl : entity is "ALUControl";
end CPU_ALUControl_0_1_ALUControl;

architecture STRUCTURE of CPU_ALUControl_0_1_ALUControl is
begin
\ALUControl[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0100AAAA"
    )
        port map (
      I0 => ALUOp(0),
      I1 => Instruction(2),
      I2 => Instruction(3),
      I3 => Instruction(0),
      I4 => ALUOp(1),
      O => ALUControl(0)
    );
\ALUControl[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000020"
    )
        port map (
      I0 => Instruction(1),
      I1 => Instruction(3),
      I2 => ALUOp(1),
      I3 => ALUOp(0),
      I4 => Instruction(2),
      O => ALUControl(1)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_ALUControl_0_1 is
  port (
    Instruction : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ALUOp : in STD_LOGIC_VECTOR ( 1 downto 0 );
    ALUControl : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_ALUControl_0_1 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_ALUControl_0_1 : entity is "CPU_ALUControl_0_1,ALUControl,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_ALUControl_0_1 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_ALUControl_0_1 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_ALUControl_0_1 : entity is "ALUControl,Vivado 2025.2";
end CPU_ALUControl_0_1;

architecture STRUCTURE of CPU_ALUControl_0_1 is
  signal \<const0>\ : STD_LOGIC;
  signal \^alucontrol\ : STD_LOGIC_VECTOR ( 1 downto 0 );
begin
  ALUControl(3) <= \<const0>\;
  ALUControl(2) <= \<const0>\;
  ALUControl(1 downto 0) <= \^alucontrol\(1 downto 0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.CPU_ALUControl_0_1_ALUControl
     port map (
      ALUControl(1 downto 0) => \^alucontrol\(1 downto 0),
      ALUOp(1 downto 0) => ALUOp(1 downto 0),
      Instruction(3 downto 0) => Instruction(3 downto 0)
    );
end STRUCTURE;
