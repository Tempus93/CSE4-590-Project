// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:56:49 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_RegisterFile_0_0/CPU_RegisterFile_0_0_stub.v
// Design      : CPU_RegisterFile_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "CPU_RegisterFile_0_0,RegisterFile,{}" *) (* CORE_GENERATION_INFO = "CPU_RegisterFile_0_0,RegisterFile,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=RegisterFile,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "RegisterFile,Vivado 2025.2" *) 
module CPU_RegisterFile_0_0(clk, read_reg1, read_reg2, write_reg, write_data, 
  reg_write, read_data1, read_data2)
/* synthesis syn_black_box black_box_pad_pin="read_reg1[3:0],read_reg2[3:0],write_reg[3:0],write_data[15:0],reg_write,read_data1[15:0],read_data2[15:0]" */
/* synthesis syn_force_seq_prim="clk" */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN CPU_clk, INSERT_VIP 0" *) input clk /* synthesis syn_isclock = 1 */;
  input [3:0]read_reg1;
  input [3:0]read_reg2;
  input [3:0]write_reg;
  input [15:0]write_data;
  input reg_write;
  output [15:0]read_data1;
  output [15:0]read_data2;
endmodule
