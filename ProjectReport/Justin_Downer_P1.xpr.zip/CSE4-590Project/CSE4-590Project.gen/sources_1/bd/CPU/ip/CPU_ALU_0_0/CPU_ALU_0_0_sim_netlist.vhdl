-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:50:47 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_ALU_0_0/CPU_ALU_0_0_sim_netlist.vhdl
-- Design      : CPU_ALU_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_ALU_0_0_ALU is
  port (
    zero : out STD_LOGIC;
    ALUResult : out STD_LOGIC_VECTOR ( 15 downto 0 );
    ReadData2 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    ALUControl : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ReadData1 : in STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_ALU_0_0_ALU : entity is "ALU";
end CPU_ALU_0_0_ALU;

architecture STRUCTURE of CPU_ALU_0_0_ALU is
  signal \^aluresult\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal ALUResult01_in : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal ALUResult02_in : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \ALUResult0_inferred__1/i__carry__0_n_0\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__0_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__0_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__0_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__1_n_0\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__1_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__1_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__1_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__2_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__2_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry__2_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry_n_0\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__1/i__carry_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__0_n_0\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__0_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__0_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__0_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__1_n_0\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__1_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__1_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__1_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__2_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__2_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry__2_n_3\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry_n_0\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry_n_1\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry_n_2\ : STD_LOGIC;
  signal \ALUResult0_inferred__2/i__carry_n_3\ : STD_LOGIC;
  signal \ALUResult[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[10]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[10]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[11]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[11]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[11]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[12]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[12]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[13]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[13]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[13]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \ALUResult[14]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \ALUResult[15]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[15]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[15]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[15]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \ALUResult[1]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[1]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[2]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[2]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[5]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[6]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[6]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[7]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[7]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \ALUResult[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \ALUResult[9]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \ALUResult[9]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_4_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_0\ : STD_LOGIC;
  signal zero_INST_0_i_1_n_0 : STD_LOGIC;
  signal zero_INST_0_i_2_n_0 : STD_LOGIC;
  signal zero_INST_0_i_3_n_0 : STD_LOGIC;
  signal \NLW_ALUResult0_inferred__1/i__carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_ALUResult0_inferred__2/i__carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__1/i__carry\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__1/i__carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__1/i__carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__1/i__carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__2/i__carry\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__2/i__carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__2/i__carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \ALUResult0_inferred__2/i__carry__2\ : label is 35;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \ALUResult[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \ALUResult[11]_INST_0_i_2\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \ALUResult[12]_INST_0_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \ALUResult[13]_INST_0_i_2\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \ALUResult[13]_INST_0_i_3\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \ALUResult[14]_INST_0_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \ALUResult[14]_INST_0_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \ALUResult[14]_INST_0_i_3\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \ALUResult[14]_INST_0_i_6\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \ALUResult[14]_INST_0_i_7\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ALUResult[15]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \ALUResult[1]_INST_0_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \ALUResult[2]_INST_0_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \ALUResult[3]_INST_0_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \ALUResult[4]_INST_0_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \ALUResult[7]_INST_0_i_3\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \ALUResult[8]_INST_0_i_3\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of zero_INST_0_i_1 : label is "soft_lutpair5";
begin
  ALUResult(15 downto 0) <= \^aluresult\(15 downto 0);
\ALUResult0_inferred__1/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ALUResult0_inferred__1/i__carry_n_0\,
      CO(2) => \ALUResult0_inferred__1/i__carry_n_1\,
      CO(1) => \ALUResult0_inferred__1/i__carry_n_2\,
      CO(0) => \ALUResult0_inferred__1/i__carry_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => ReadData1(3 downto 0),
      O(3 downto 0) => ALUResult01_in(3 downto 0),
      S(3) => \i__carry_i_1__3_n_0\,
      S(2) => \i__carry_i_2__3_n_0\,
      S(1) => \i__carry_i_3__3_n_0\,
      S(0) => \i__carry_i_4__3_n_0\
    );
\ALUResult0_inferred__1/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \ALUResult0_inferred__1/i__carry_n_0\,
      CO(3) => \ALUResult0_inferred__1/i__carry__0_n_0\,
      CO(2) => \ALUResult0_inferred__1/i__carry__0_n_1\,
      CO(1) => \ALUResult0_inferred__1/i__carry__0_n_2\,
      CO(0) => \ALUResult0_inferred__1/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => ReadData1(7 downto 4),
      O(3 downto 0) => ALUResult01_in(7 downto 4),
      S(3) => \i__carry__0_i_1_n_0\,
      S(2) => \i__carry__0_i_2_n_0\,
      S(1) => \i__carry__0_i_3_n_0\,
      S(0) => \i__carry__0_i_4_n_0\
    );
\ALUResult0_inferred__1/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \ALUResult0_inferred__1/i__carry__0_n_0\,
      CO(3) => \ALUResult0_inferred__1/i__carry__1_n_0\,
      CO(2) => \ALUResult0_inferred__1/i__carry__1_n_1\,
      CO(1) => \ALUResult0_inferred__1/i__carry__1_n_2\,
      CO(0) => \ALUResult0_inferred__1/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => ReadData1(11 downto 8),
      O(3 downto 0) => ALUResult01_in(11 downto 8),
      S(3) => \i__carry__1_i_1_n_0\,
      S(2) => \i__carry__1_i_2_n_0\,
      S(1) => \i__carry__1_i_3_n_0\,
      S(0) => \i__carry__1_i_4_n_0\
    );
\ALUResult0_inferred__1/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \ALUResult0_inferred__1/i__carry__1_n_0\,
      CO(3) => \NLW_ALUResult0_inferred__1/i__carry__2_CO_UNCONNECTED\(3),
      CO(2) => \ALUResult0_inferred__1/i__carry__2_n_1\,
      CO(1) => \ALUResult0_inferred__1/i__carry__2_n_2\,
      CO(0) => \ALUResult0_inferred__1/i__carry__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => ReadData1(14 downto 12),
      O(3 downto 0) => ALUResult01_in(15 downto 12),
      S(3) => \i__carry__2_i_1_n_0\,
      S(2) => \i__carry__2_i_2_n_0\,
      S(1) => \i__carry__2_i_3_n_0\,
      S(0) => \i__carry__2_i_4_n_0\
    );
\ALUResult0_inferred__2/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ALUResult0_inferred__2/i__carry_n_0\,
      CO(2) => \ALUResult0_inferred__2/i__carry_n_1\,
      CO(1) => \ALUResult0_inferred__2/i__carry_n_2\,
      CO(0) => \ALUResult0_inferred__2/i__carry_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => ReadData1(3 downto 0),
      O(3 downto 0) => ALUResult02_in(3 downto 0),
      S(3) => \i__carry_i_1__2_n_0\,
      S(2) => \i__carry_i_2__2_n_0\,
      S(1) => \i__carry_i_3__2_n_0\,
      S(0) => \i__carry_i_4__2_n_0\
    );
\ALUResult0_inferred__2/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \ALUResult0_inferred__2/i__carry_n_0\,
      CO(3) => \ALUResult0_inferred__2/i__carry__0_n_0\,
      CO(2) => \ALUResult0_inferred__2/i__carry__0_n_1\,
      CO(1) => \ALUResult0_inferred__2/i__carry__0_n_2\,
      CO(0) => \ALUResult0_inferred__2/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => ReadData1(7 downto 4),
      O(3 downto 0) => ALUResult02_in(7 downto 4),
      S(3) => \i__carry_i_1__1_n_0\,
      S(2) => \i__carry_i_2__1_n_0\,
      S(1) => \i__carry_i_3__1_n_0\,
      S(0) => \i__carry_i_4__1_n_0\
    );
\ALUResult0_inferred__2/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \ALUResult0_inferred__2/i__carry__0_n_0\,
      CO(3) => \ALUResult0_inferred__2/i__carry__1_n_0\,
      CO(2) => \ALUResult0_inferred__2/i__carry__1_n_1\,
      CO(1) => \ALUResult0_inferred__2/i__carry__1_n_2\,
      CO(0) => \ALUResult0_inferred__2/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => ReadData1(11 downto 8),
      O(3 downto 0) => ALUResult02_in(11 downto 8),
      S(3) => \i__carry_i_1__0_n_0\,
      S(2) => \i__carry_i_2__0_n_0\,
      S(1) => \i__carry_i_3__0_n_0\,
      S(0) => \i__carry_i_4__0_n_0\
    );
\ALUResult0_inferred__2/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \ALUResult0_inferred__2/i__carry__1_n_0\,
      CO(3) => \NLW_ALUResult0_inferred__2/i__carry__2_CO_UNCONNECTED\(3),
      CO(2) => \ALUResult0_inferred__2/i__carry__2_n_1\,
      CO(1) => \ALUResult0_inferred__2/i__carry__2_n_2\,
      CO(0) => \ALUResult0_inferred__2/i__carry__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => ReadData1(14 downto 12),
      O(3 downto 0) => ALUResult02_in(15 downto 12),
      S(3) => \i__carry_i_1_n_0\,
      S(2) => \i__carry_i_2_n_0\,
      S(1) => \i__carry_i_3_n_0\,
      S(0) => \i__carry_i_4_n_0\
    );
\ALUResult[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10111010"
    )
        port map (
      I0 => ALUControl(3),
      I1 => ALUControl(2),
      I2 => \ALUResult[0]_INST_0_i_1_n_0\,
      I3 => \ALUResult[1]_INST_0_i_2_n_0\,
      I4 => \ALUResult[14]_INST_0_i_6_n_0\,
      O => \^aluresult\(0)
    );
\ALUResult[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F000CCCC0000AAAA"
    )
        port map (
      I0 => ALUResult02_in(0),
      I1 => ALUResult01_in(0),
      I2 => ReadData2(0),
      I3 => ReadData1(0),
      I4 => ALUControl(1),
      I5 => ALUControl(0),
      O => \ALUResult[0]_INST_0_i_1_n_0\
    );
\ALUResult[10]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA80AA80AA80"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[14]_INST_0_i_2_n_0\,
      I2 => \ALUResult[10]_INST_0_i_1_n_0\,
      I3 => \ALUResult[10]_INST_0_i_2_n_0\,
      I4 => \ALUResult[14]_INST_0_i_6_n_0\,
      I5 => \ALUResult[11]_INST_0_i_2_n_0\,
      O => \^aluresult\(10)
    );
\ALUResult[10]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00B8FFFF00B80000"
    )
        port map (
      I0 => ReadData1(3),
      I1 => ReadData2(2),
      I2 => ReadData1(7),
      I3 => ReadData2(3),
      I4 => ReadData2(1),
      I5 => \ALUResult[12]_INST_0_i_3_n_0\,
      O => \ALUResult[10]_INST_0_i_1_n_0\
    );
\ALUResult[10]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(10),
      I1 => ReadData1(10),
      I2 => ALUResult01_in(10),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(10),
      O => \ALUResult[10]_INST_0_i_2_n_0\
    );
\ALUResult[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA80AA80AA80"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[14]_INST_0_i_6_n_0\,
      I2 => \ALUResult[12]_INST_0_i_1_n_0\,
      I3 => \ALUResult[11]_INST_0_i_1_n_0\,
      I4 => \ALUResult[14]_INST_0_i_2_n_0\,
      I5 => \ALUResult[11]_INST_0_i_2_n_0\,
      O => \^aluresult\(11)
    );
\ALUResult[11]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(11),
      I1 => ReadData1(11),
      I2 => ALUResult01_in(11),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(11),
      O => \ALUResult[11]_INST_0_i_1_n_0\
    );
\ALUResult[11]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ALUResult[11]_INST_0_i_3_n_0\,
      I1 => ReadData2(1),
      I2 => \ALUResult[13]_INST_0_i_3_n_0\,
      O => \ALUResult[11]_INST_0_i_2_n_0\
    );
\ALUResult[11]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => ReadData1(4),
      I1 => ReadData2(2),
      I2 => ReadData1(0),
      I3 => ReadData2(3),
      I4 => ReadData1(8),
      O => \ALUResult[11]_INST_0_i_3_n_0\
    );
\ALUResult[12]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA80AA80AA80"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[14]_INST_0_i_2_n_0\,
      I2 => \ALUResult[12]_INST_0_i_1_n_0\,
      I3 => \ALUResult[12]_INST_0_i_2_n_0\,
      I4 => \ALUResult[14]_INST_0_i_6_n_0\,
      I5 => \ALUResult[13]_INST_0_i_2_n_0\,
      O => \^aluresult\(12)
    );
\ALUResult[12]_INST_0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ALUResult[12]_INST_0_i_3_n_0\,
      I1 => ReadData2(1),
      I2 => \ALUResult[14]_INST_0_i_7_n_0\,
      O => \ALUResult[12]_INST_0_i_1_n_0\
    );
\ALUResult[12]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(12),
      I1 => ReadData1(12),
      I2 => ALUResult01_in(12),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(12),
      O => \ALUResult[12]_INST_0_i_2_n_0\
    );
\ALUResult[12]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => ReadData1(5),
      I1 => ReadData2(2),
      I2 => ReadData1(1),
      I3 => ReadData2(3),
      I4 => ReadData1(9),
      O => \ALUResult[12]_INST_0_i_3_n_0\
    );
\ALUResult[13]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA80AA80AA80"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[14]_INST_0_i_6_n_0\,
      I2 => \ALUResult[14]_INST_0_i_3_n_0\,
      I3 => \ALUResult[13]_INST_0_i_1_n_0\,
      I4 => \ALUResult[14]_INST_0_i_2_n_0\,
      I5 => \ALUResult[13]_INST_0_i_2_n_0\,
      O => \^aluresult\(13)
    );
\ALUResult[13]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800FFF0880000F0"
    )
        port map (
      I0 => ReadData2(13),
      I1 => ReadData1(13),
      I2 => ALUResult02_in(13),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult01_in(13),
      O => \ALUResult[13]_INST_0_i_1_n_0\
    );
\ALUResult[13]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ALUResult[13]_INST_0_i_3_n_0\,
      I1 => ReadData2(1),
      I2 => \ALUResult[14]_INST_0_i_9_n_0\,
      O => \ALUResult[13]_INST_0_i_2_n_0\
    );
\ALUResult[13]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => ReadData1(6),
      I1 => ReadData2(2),
      I2 => ReadData1(2),
      I3 => ReadData2(3),
      I4 => ReadData1(10),
      O => \ALUResult[13]_INST_0_i_3_n_0\
    );
\ALUResult[14]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA80AA80AA80"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[14]_INST_0_i_2_n_0\,
      I2 => \ALUResult[14]_INST_0_i_3_n_0\,
      I3 => \ALUResult[14]_INST_0_i_4_n_0\,
      I4 => \ALUResult[14]_INST_0_i_5_n_0\,
      I5 => \ALUResult[14]_INST_0_i_6_n_0\,
      O => \^aluresult\(14)
    );
\ALUResult[14]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => ALUControl(2),
      I1 => ALUControl(3),
      O => \ALUResult[14]_INST_0_i_1_n_0\
    );
\ALUResult[14]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => ReadData1(2),
      I1 => ReadData1(10),
      I2 => ReadData2(2),
      I3 => ReadData1(6),
      I4 => ReadData2(3),
      I5 => ReadData1(14),
      O => \ALUResult[14]_INST_0_i_10_n_0\
    );
\ALUResult[14]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => ReadData2(0),
      I1 => ALUControl(1),
      I2 => ALUControl(0),
      O => \ALUResult[14]_INST_0_i_2_n_0\
    );
\ALUResult[14]_INST_0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_7_n_0\,
      I1 => ReadData2(1),
      I2 => \ALUResult[14]_INST_0_i_8_n_0\,
      O => \ALUResult[14]_INST_0_i_3_n_0\
    );
\ALUResult[14]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(14),
      I1 => ReadData1(14),
      I2 => ALUResult01_in(14),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(14),
      O => \ALUResult[14]_INST_0_i_4_n_0\
    );
\ALUResult[14]_INST_0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_9_n_0\,
      I1 => ReadData2(1),
      I2 => \ALUResult[14]_INST_0_i_10_n_0\,
      O => \ALUResult[14]_INST_0_i_5_n_0\
    );
\ALUResult[14]_INST_0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => ReadData2(0),
      I1 => ALUControl(1),
      I2 => ALUControl(0),
      O => \ALUResult[14]_INST_0_i_6_n_0\
    );
\ALUResult[14]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => ReadData1(7),
      I1 => ReadData2(2),
      I2 => ReadData1(3),
      I3 => ReadData2(3),
      I4 => ReadData1(11),
      O => \ALUResult[14]_INST_0_i_7_n_0\
    );
\ALUResult[14]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => ReadData1(1),
      I1 => ReadData1(9),
      I2 => ReadData2(2),
      I3 => ReadData1(5),
      I4 => ReadData2(3),
      I5 => ReadData1(13),
      O => \ALUResult[14]_INST_0_i_8_n_0\
    );
\ALUResult[14]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => ReadData1(0),
      I1 => ReadData1(8),
      I2 => ReadData2(2),
      I3 => ReadData1(4),
      I4 => ReadData2(3),
      I5 => ReadData1(12),
      O => \ALUResult[14]_INST_0_i_9_n_0\
    );
\ALUResult[15]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \ALUResult[15]_INST_0_i_1_n_0\,
      O => \^aluresult\(15)
    );
\ALUResult[15]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF0111"
    )
        port map (
      I0 => \ALUResult[15]_INST_0_i_2_n_0\,
      I1 => \ALUResult[15]_INST_0_i_3_n_0\,
      I2 => \ALUResult[14]_INST_0_i_5_n_0\,
      I3 => \ALUResult[14]_INST_0_i_2_n_0\,
      I4 => ALUControl(3),
      I5 => ALUControl(2),
      O => \ALUResult[15]_INST_0_i_1_n_0\
    );
\ALUResult[15]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404040000040000"
    )
        port map (
      I0 => ALUControl(0),
      I1 => ALUControl(1),
      I2 => ReadData2(0),
      I3 => ReadData2(1),
      I4 => \ALUResult[15]_INST_0_i_4_n_0\,
      I5 => \ALUResult[14]_INST_0_i_8_n_0\,
      O => \ALUResult[15]_INST_0_i_2_n_0\
    );
\ALUResult[15]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0CA00CA00CA00CA"
    )
        port map (
      I0 => ALUResult02_in(15),
      I1 => ALUResult01_in(15),
      I2 => ALUControl(0),
      I3 => ALUControl(1),
      I4 => ReadData2(15),
      I5 => ReadData1(15),
      O => \ALUResult[15]_INST_0_i_3_n_0\
    );
\ALUResult[15]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => ReadData1(3),
      I1 => ReadData1(11),
      I2 => ReadData2(2),
      I3 => ReadData1(7),
      I4 => ReadData2(3),
      I5 => ReadData1(15),
      O => \ALUResult[15]_INST_0_i_4_n_0\
    );
\ALUResult[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A88AAAA8A888A88"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[1]_INST_0_i_1_n_0\,
      I2 => \ALUResult[2]_INST_0_i_1_n_0\,
      I3 => \ALUResult[14]_INST_0_i_6_n_0\,
      I4 => \ALUResult[1]_INST_0_i_2_n_0\,
      I5 => \ALUResult[14]_INST_0_i_2_n_0\,
      O => \^aluresult\(1)
    );
\ALUResult[1]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(1),
      I1 => ReadData1(1),
      I2 => ALUResult01_in(1),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(1),
      O => \ALUResult[1]_INST_0_i_1_n_0\
    );
\ALUResult[1]_INST_0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => ReadData2(1),
      I1 => ReadData2(3),
      I2 => ReadData1(0),
      I3 => ReadData2(2),
      O => \ALUResult[1]_INST_0_i_2_n_0\
    );
\ALUResult[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA20AAAAAA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[2]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_2_n_0\,
      I3 => \ALUResult[2]_INST_0_i_2_n_0\,
      I4 => \ALUResult[3]_INST_0_i_2_n_0\,
      I5 => \ALUResult[14]_INST_0_i_6_n_0\,
      O => \^aluresult\(2)
    );
\ALUResult[2]_INST_0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => ReadData2(1),
      I1 => ReadData2(3),
      I2 => ReadData1(1),
      I3 => ReadData2(2),
      O => \ALUResult[2]_INST_0_i_1_n_0\
    );
\ALUResult[2]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(2),
      I1 => ReadData1(2),
      I2 => ALUResult01_in(2),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(2),
      O => \ALUResult[2]_INST_0_i_2_n_0\
    );
\ALUResult[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA20AAAAAA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[4]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_6_n_0\,
      I3 => \ALUResult[3]_INST_0_i_1_n_0\,
      I4 => \ALUResult[3]_INST_0_i_2_n_0\,
      I5 => \ALUResult[14]_INST_0_i_2_n_0\,
      O => \^aluresult\(3)
    );
\ALUResult[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(3),
      I1 => ReadData1(3),
      I2 => ALUResult01_in(3),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(3),
      O => \ALUResult[3]_INST_0_i_1_n_0\
    );
\ALUResult[3]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF4F7"
    )
        port map (
      I0 => ReadData1(0),
      I1 => ReadData2(1),
      I2 => ReadData2(2),
      I3 => ReadData1(2),
      I4 => ReadData2(3),
      O => \ALUResult[3]_INST_0_i_2_n_0\
    );
\ALUResult[4]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA20AAAAAA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[4]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_2_n_0\,
      I3 => \ALUResult[4]_INST_0_i_2_n_0\,
      I4 => \ALUResult[5]_INST_0_i_1_n_0\,
      I5 => \ALUResult[14]_INST_0_i_6_n_0\,
      O => \^aluresult\(4)
    );
\ALUResult[4]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF4F7"
    )
        port map (
      I0 => ReadData1(1),
      I1 => ReadData2(1),
      I2 => ReadData2(2),
      I3 => ReadData1(3),
      I4 => ReadData2(3),
      O => \ALUResult[4]_INST_0_i_1_n_0\
    );
\ALUResult[4]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(4),
      I1 => ReadData1(4),
      I2 => ALUResult01_in(4),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(4),
      O => \ALUResult[4]_INST_0_i_2_n_0\
    );
\ALUResult[5]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA20AAAAAA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[5]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_2_n_0\,
      I3 => \ALUResult[5]_INST_0_i_2_n_0\,
      I4 => \ALUResult[6]_INST_0_i_1_n_0\,
      I5 => \ALUResult[14]_INST_0_i_6_n_0\,
      O => \^aluresult\(5)
    );
\ALUResult[5]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFCF44FFFFCF77"
    )
        port map (
      I0 => ReadData1(2),
      I1 => ReadData2(1),
      I2 => ReadData1(0),
      I3 => ReadData2(2),
      I4 => ReadData2(3),
      I5 => ReadData1(4),
      O => \ALUResult[5]_INST_0_i_1_n_0\
    );
\ALUResult[5]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(5),
      I1 => ReadData1(5),
      I2 => ALUResult01_in(5),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(5),
      O => \ALUResult[5]_INST_0_i_2_n_0\
    );
\ALUResult[6]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA20AAAAAA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[6]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_2_n_0\,
      I3 => \ALUResult[6]_INST_0_i_2_n_0\,
      I4 => \ALUResult[7]_INST_0_i_2_n_0\,
      I5 => \ALUResult[14]_INST_0_i_6_n_0\,
      O => \^aluresult\(6)
    );
\ALUResult[6]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFCF44CF77"
    )
        port map (
      I0 => ReadData1(3),
      I1 => ReadData2(1),
      I2 => ReadData1(1),
      I3 => ReadData2(2),
      I4 => ReadData1(5),
      I5 => ReadData2(3),
      O => \ALUResult[6]_INST_0_i_1_n_0\
    );
\ALUResult[6]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(6),
      I1 => ReadData1(6),
      I2 => ALUResult01_in(6),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(6),
      O => \ALUResult[6]_INST_0_i_2_n_0\
    );
\ALUResult[7]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA20AAAAAA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[8]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_6_n_0\,
      I3 => \ALUResult[7]_INST_0_i_1_n_0\,
      I4 => \ALUResult[7]_INST_0_i_2_n_0\,
      I5 => \ALUResult[14]_INST_0_i_2_n_0\,
      O => \^aluresult\(7)
    );
\ALUResult[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800FFF0880000F0"
    )
        port map (
      I0 => ReadData2(7),
      I1 => ReadData1(7),
      I2 => ALUResult02_in(7),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult01_in(7),
      O => \ALUResult[7]_INST_0_i_1_n_0\
    );
\ALUResult[7]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F4F70000F4F7FFFF"
    )
        port map (
      I0 => ReadData1(0),
      I1 => ReadData2(2),
      I2 => ReadData2(3),
      I3 => ReadData1(4),
      I4 => ReadData2(1),
      I5 => \ALUResult[7]_INST_0_i_3_n_0\,
      O => \ALUResult[7]_INST_0_i_2_n_0\
    );
\ALUResult[7]_INST_0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00E2"
    )
        port map (
      I0 => ReadData1(6),
      I1 => ReadData2(2),
      I2 => ReadData1(2),
      I3 => ReadData2(3),
      O => \ALUResult[7]_INST_0_i_3_n_0\
    );
\ALUResult[8]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA20AA20AA20"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[8]_INST_0_i_1_n_0\,
      I2 => \ALUResult[14]_INST_0_i_2_n_0\,
      I3 => \ALUResult[8]_INST_0_i_2_n_0\,
      I4 => \ALUResult[14]_INST_0_i_6_n_0\,
      I5 => \ALUResult[9]_INST_0_i_1_n_0\,
      O => \^aluresult\(8)
    );
\ALUResult[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF47FFFFFF470000"
    )
        port map (
      I0 => ReadData1(1),
      I1 => ReadData2(2),
      I2 => ReadData1(5),
      I3 => ReadData2(3),
      I4 => ReadData2(1),
      I5 => \ALUResult[8]_INST_0_i_3_n_0\,
      O => \ALUResult[8]_INST_0_i_1_n_0\
    );
\ALUResult[8]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800F0FF8800F000"
    )
        port map (
      I0 => ReadData2(8),
      I1 => ReadData1(8),
      I2 => ALUResult01_in(8),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult02_in(8),
      O => \ALUResult[8]_INST_0_i_2_n_0\
    );
\ALUResult[8]_INST_0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF47"
    )
        port map (
      I0 => ReadData1(3),
      I1 => ReadData2(2),
      I2 => ReadData1(7),
      I3 => ReadData2(3),
      O => \ALUResult[8]_INST_0_i_3_n_0\
    );
\ALUResult[9]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA80AA80AA80"
    )
        port map (
      I0 => \ALUResult[14]_INST_0_i_1_n_0\,
      I1 => \ALUResult[14]_INST_0_i_2_n_0\,
      I2 => \ALUResult[9]_INST_0_i_1_n_0\,
      I3 => \ALUResult[9]_INST_0_i_2_n_0\,
      I4 => \ALUResult[14]_INST_0_i_6_n_0\,
      I5 => \ALUResult[10]_INST_0_i_1_n_0\,
      O => \^aluresult\(9)
    );
\ALUResult[9]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => ReadData1(6),
      I1 => ReadData2(2),
      I2 => ReadData1(2),
      I3 => ReadData2(3),
      I4 => ReadData2(1),
      I5 => \ALUResult[11]_INST_0_i_3_n_0\,
      O => \ALUResult[9]_INST_0_i_1_n_0\
    );
\ALUResult[9]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8800FFF0880000F0"
    )
        port map (
      I0 => ReadData2(9),
      I1 => ReadData1(9),
      I2 => ALUResult02_in(9),
      I3 => ALUControl(0),
      I4 => ALUControl(1),
      I5 => ALUResult01_in(9),
      O => \ALUResult[9]_INST_0_i_2_n_0\
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(7),
      I1 => ReadData2(7),
      O => \i__carry__0_i_1_n_0\
    );
\i__carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(6),
      I1 => ReadData2(6),
      O => \i__carry__0_i_2_n_0\
    );
\i__carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(5),
      I1 => ReadData2(5),
      O => \i__carry__0_i_3_n_0\
    );
\i__carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(4),
      I1 => ReadData2(4),
      O => \i__carry__0_i_4_n_0\
    );
\i__carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(11),
      I1 => ReadData2(11),
      O => \i__carry__1_i_1_n_0\
    );
\i__carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(10),
      I1 => ReadData2(10),
      O => \i__carry__1_i_2_n_0\
    );
\i__carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(9),
      I1 => ReadData2(9),
      O => \i__carry__1_i_3_n_0\
    );
\i__carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(8),
      I1 => ReadData2(8),
      O => \i__carry__1_i_4_n_0\
    );
\i__carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData2(15),
      I1 => ReadData1(15),
      O => \i__carry__2_i_1_n_0\
    );
\i__carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(14),
      I1 => ReadData2(14),
      O => \i__carry__2_i_2_n_0\
    );
\i__carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(13),
      I1 => ReadData2(13),
      O => \i__carry__2_i_3_n_0\
    );
\i__carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(12),
      I1 => ReadData2(12),
      O => \i__carry__2_i_4_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData1(15),
      I1 => ReadData2(15),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(11),
      I1 => ReadData1(11),
      O => \i__carry_i_1__0_n_0\
    );
\i__carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(7),
      I1 => ReadData1(7),
      O => \i__carry_i_1__1_n_0\
    );
\i__carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(3),
      I1 => ReadData1(3),
      O => \i__carry_i_1__2_n_0\
    );
\i__carry_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(3),
      I1 => ReadData2(3),
      O => \i__carry_i_1__3_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(14),
      I1 => ReadData1(14),
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(10),
      I1 => ReadData1(10),
      O => \i__carry_i_2__0_n_0\
    );
\i__carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(6),
      I1 => ReadData1(6),
      O => \i__carry_i_2__1_n_0\
    );
\i__carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(2),
      I1 => ReadData1(2),
      O => \i__carry_i_2__2_n_0\
    );
\i__carry_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(2),
      I1 => ReadData2(2),
      O => \i__carry_i_2__3_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(13),
      I1 => ReadData1(13),
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(9),
      I1 => ReadData1(9),
      O => \i__carry_i_3__0_n_0\
    );
\i__carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(5),
      I1 => ReadData1(5),
      O => \i__carry_i_3__1_n_0\
    );
\i__carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(1),
      I1 => ReadData1(1),
      O => \i__carry_i_3__2_n_0\
    );
\i__carry_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(1),
      I1 => ReadData2(1),
      O => \i__carry_i_3__3_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(12),
      I1 => ReadData1(12),
      O => \i__carry_i_4_n_0\
    );
\i__carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(8),
      I1 => ReadData1(8),
      O => \i__carry_i_4__0_n_0\
    );
\i__carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(4),
      I1 => ReadData1(4),
      O => \i__carry_i_4__1_n_0\
    );
\i__carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ReadData2(0),
      I1 => ReadData1(0),
      O => \i__carry_i_4__2_n_0\
    );
\i__carry_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => ReadData1(0),
      I1 => ReadData2(0),
      O => \i__carry_i_4__3_n_0\
    );
zero_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000002"
    )
        port map (
      I0 => zero_INST_0_i_1_n_0,
      I1 => zero_INST_0_i_2_n_0,
      I2 => \^aluresult\(12),
      I3 => \^aluresult\(14),
      I4 => zero_INST_0_i_3_n_0,
      O => zero
    );
zero_INST_0_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => \^aluresult\(11),
      I1 => \ALUResult[15]_INST_0_i_1_n_0\,
      I2 => \^aluresult\(9),
      I3 => \^aluresult\(13),
      O => zero_INST_0_i_1_n_0
    );
zero_INST_0_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \^aluresult\(10),
      I1 => \^aluresult\(4),
      I2 => \^aluresult\(3),
      I3 => \^aluresult\(1),
      I4 => \^aluresult\(0),
      I5 => \^aluresult\(2),
      O => zero_INST_0_i_2_n_0
    );
zero_INST_0_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \^aluresult\(5),
      I1 => \^aluresult\(7),
      I2 => \^aluresult\(6),
      I3 => \^aluresult\(8),
      O => zero_INST_0_i_3_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_ALU_0_0 is
  port (
    ReadData1 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    ReadData2 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    ALUControl : in STD_LOGIC_VECTOR ( 3 downto 0 );
    zero : out STD_LOGIC;
    ALUResult : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_ALU_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_ALU_0_0 : entity is "CPU_ALU_0_0,ALU,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_ALU_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_ALU_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_ALU_0_0 : entity is "ALU,Vivado 2025.2";
end CPU_ALU_0_0;

architecture STRUCTURE of CPU_ALU_0_0 is
begin
inst: entity work.CPU_ALU_0_0_ALU
     port map (
      ALUControl(3 downto 0) => ALUControl(3 downto 0),
      ALUResult(15 downto 0) => ALUResult(15 downto 0),
      ReadData1(15 downto 0) => ReadData1(15 downto 0),
      ReadData2(15 downto 0) => ReadData2(15 downto 0),
      zero => zero
    );
end STRUCTURE;
