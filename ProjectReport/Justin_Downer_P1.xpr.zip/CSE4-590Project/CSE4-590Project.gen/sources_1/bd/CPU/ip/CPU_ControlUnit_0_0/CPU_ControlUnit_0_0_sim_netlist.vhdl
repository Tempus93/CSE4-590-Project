-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:56:25 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_ControlUnit_0_0/CPU_ControlUnit_0_0_sim_netlist.vhdl
-- Design      : CPU_ControlUnit_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_ControlUnit_0_0_ControlUnit is
  port (
    RegDst : out STD_LOGIC;
    ALUSrc : out STD_LOGIC;
    MemtoReg : out STD_LOGIC;
    RegWrite : out STD_LOGIC;
    Branch : out STD_LOGIC;
    BNE : out STD_LOGIC;
    Jump : out STD_LOGIC;
    ALUOp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Instruction : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of CPU_ControlUnit_0_0_ControlUnit : entity is "ControlUnit";
end CPU_ControlUnit_0_0_ControlUnit;

architecture STRUCTURE of CPU_ControlUnit_0_0_ControlUnit is
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \/i_\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \ALUOp[0]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \ALUOp[1]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \__0/i_\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \__1/i_\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \__2/i_\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \__5/i_\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \__6/i_\ : label is "soft_lutpair2";
begin
\/i_\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => Instruction(2),
      I1 => Instruction(0),
      I2 => Instruction(1),
      I3 => Instruction(3),
      O => RegDst
    );
\ALUOp[0]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0070"
    )
        port map (
      I0 => Instruction(0),
      I1 => Instruction(1),
      I2 => Instruction(2),
      I3 => Instruction(3),
      O => ALUOp(0)
    );
\ALUOp[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0009"
    )
        port map (
      I0 => Instruction(1),
      I1 => Instruction(2),
      I2 => Instruction(0),
      I3 => Instruction(3),
      O => ALUOp(1)
    );
\__0/i_\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"000E"
    )
        port map (
      I0 => Instruction(0),
      I1 => Instruction(1),
      I2 => Instruction(2),
      I3 => Instruction(3),
      O => ALUSrc
    );
\__1/i_\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => Instruction(1),
      I1 => Instruction(2),
      I2 => Instruction(0),
      I3 => Instruction(3),
      O => MemtoReg
    );
\__2/i_\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"000D"
    )
        port map (
      I0 => Instruction(1),
      I1 => Instruction(0),
      I2 => Instruction(2),
      I3 => Instruction(3),
      O => RegWrite
    );
\__4/i_\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => Instruction(1),
      I1 => Instruction(2),
      I2 => Instruction(3),
      O => Branch
    );
\__5/i_\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => Instruction(2),
      I1 => Instruction(0),
      I2 => Instruction(1),
      I3 => Instruction(3),
      O => BNE
    );
\__6/i_\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => Instruction(1),
      I1 => Instruction(2),
      I2 => Instruction(0),
      I3 => Instruction(3),
      O => Jump
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_ControlUnit_0_0 is
  port (
    Instruction : in STD_LOGIC_VECTOR ( 3 downto 0 );
    RegDst : out STD_LOGIC;
    ALUSrc : out STD_LOGIC;
    MemtoReg : out STD_LOGIC;
    RegWrite : out STD_LOGIC;
    MemRead : out STD_LOGIC;
    MemWrite : out STD_LOGIC;
    Branch : out STD_LOGIC;
    BNE : out STD_LOGIC;
    Jump : out STD_LOGIC;
    ALUOp : out STD_LOGIC_VECTOR ( 1 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_ControlUnit_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_ControlUnit_0_0 : entity is "CPU_ControlUnit_0_0,ControlUnit,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_ControlUnit_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_ControlUnit_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_ControlUnit_0_0 : entity is "ControlUnit,Vivado 2025.2";
end CPU_ControlUnit_0_0;

architecture STRUCTURE of CPU_ControlUnit_0_0 is
  signal \^memtoreg\ : STD_LOGIC;
begin
  MemRead <= \^memtoreg\;
  MemtoReg <= \^memtoreg\;
MemWrite_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => Instruction(2),
      I1 => Instruction(0),
      I2 => Instruction(1),
      I3 => Instruction(3),
      O => MemWrite
    );
inst: entity work.CPU_ControlUnit_0_0_ControlUnit
     port map (
      ALUOp(1 downto 0) => ALUOp(1 downto 0),
      ALUSrc => ALUSrc,
      BNE => BNE,
      Branch => Branch,
      Instruction(3 downto 0) => Instruction(3 downto 0),
      Jump => Jump,
      MemtoReg => \^memtoreg\,
      RegDst => RegDst,
      RegWrite => RegWrite
    );
end STRUCTURE;
