-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:56:50 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_SignExt_0_0/CPU_SignExt_0_0_sim_netlist.vhdl
-- Design      : CPU_SignExt_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity CPU_SignExt_0_0 is
  port (
    imm_value : in STD_LOGIC_VECTOR ( 3 downto 0 );
    result : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of CPU_SignExt_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_SignExt_0_0 : entity is "CPU_SignExt_0_0,SignExt,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_SignExt_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_SignExt_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of CPU_SignExt_0_0 : entity is "SignExt,Vivado 2025.2";
end CPU_SignExt_0_0;

architecture STRUCTURE of CPU_SignExt_0_0 is
  signal \^imm_value\ : STD_LOGIC_VECTOR ( 3 downto 0 );
begin
  \^imm_value\(3 downto 0) <= imm_value(3 downto 0);
  result(15) <= \^imm_value\(3);
  result(14) <= \^imm_value\(3);
  result(13) <= \^imm_value\(3);
  result(12) <= \^imm_value\(3);
  result(11) <= \^imm_value\(3);
  result(10) <= \^imm_value\(3);
  result(9) <= \^imm_value\(3);
  result(8) <= \^imm_value\(3);
  result(7) <= \^imm_value\(3);
  result(6) <= \^imm_value\(3);
  result(5) <= \^imm_value\(3);
  result(4) <= \^imm_value\(3);
  result(3 downto 0) <= \^imm_value\(3 downto 0);
end STRUCTURE;
