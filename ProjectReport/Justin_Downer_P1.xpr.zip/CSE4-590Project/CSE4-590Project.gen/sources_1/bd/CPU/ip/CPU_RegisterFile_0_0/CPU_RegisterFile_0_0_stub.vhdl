-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Mar 24 20:56:49 2026
-- Host        : Justin-T480 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_RegisterFile_0_0/CPU_RegisterFile_0_0_stub.vhdl
-- Design      : CPU_RegisterFile_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity CPU_RegisterFile_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    read_reg1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    read_reg2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    write_reg : in STD_LOGIC_VECTOR ( 3 downto 0 );
    write_data : in STD_LOGIC_VECTOR ( 15 downto 0 );
    reg_write : in STD_LOGIC;
    read_data1 : out STD_LOGIC_VECTOR ( 15 downto 0 );
    read_data2 : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of CPU_RegisterFile_0_0 : entity is "CPU_RegisterFile_0_0,RegisterFile,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of CPU_RegisterFile_0_0 : entity is "CPU_RegisterFile_0_0,RegisterFile,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=RegisterFile,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of CPU_RegisterFile_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of CPU_RegisterFile_0_0 : entity is "module_ref";
end CPU_RegisterFile_0_0;

architecture stub of CPU_RegisterFile_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "clk,read_reg1[3:0],read_reg2[3:0],write_reg[3:0],write_data[15:0],reg_write,read_data1[15:0],read_data2[15:0]";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN CPU_clk, INSERT_VIP 0";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "RegisterFile,Vivado 2025.2";
begin
end;
