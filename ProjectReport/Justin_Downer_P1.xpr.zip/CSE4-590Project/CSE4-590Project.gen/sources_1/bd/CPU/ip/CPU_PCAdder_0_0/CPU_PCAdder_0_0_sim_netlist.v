// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:58:51 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_PCAdder_0_0/CPU_PCAdder_0_0_sim_netlist.v
// Design      : CPU_PCAdder_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CPU_PCAdder_0_0,PCAdder,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "PCAdder,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module CPU_PCAdder_0_0
   (pc_in,
    imm_shifted,
    pc_next,
    pc_branch);
  input [15:0]pc_in;
  input [15:0]imm_shifted;
  output [15:0]pc_next;
  output [15:0]pc_branch;

  wire [15:0]imm_shifted;
  wire [15:0]pc_branch;
  wire [15:0]pc_in;
  wire [15:0]pc_next;

  CPU_PCAdder_0_0_PCAdder inst
       (.imm_shifted(imm_shifted),
        .pc_branch(pc_branch),
        .pc_in(pc_in),
        .pc_next(pc_next));
endmodule

(* ORIG_REF_NAME = "PCAdder" *) 
module CPU_PCAdder_0_0_PCAdder
   (pc_next,
    pc_branch,
    imm_shifted,
    pc_in);
  output [15:0]pc_next;
  output [15:0]pc_branch;
  input [15:0]imm_shifted;
  input [15:0]pc_in;

  wire [15:0]imm_shifted;
  wire [15:0]pc_branch;
  wire pc_branch_carry__0_n_0;
  wire pc_branch_carry__0_n_1;
  wire pc_branch_carry__0_n_2;
  wire pc_branch_carry__0_n_3;
  wire pc_branch_carry__1_n_0;
  wire pc_branch_carry__1_n_1;
  wire pc_branch_carry__1_n_2;
  wire pc_branch_carry__1_n_3;
  wire pc_branch_carry__2_n_1;
  wire pc_branch_carry__2_n_2;
  wire pc_branch_carry__2_n_3;
  wire pc_branch_carry_i_1__0_n_0;
  wire pc_branch_carry_i_1__1_n_0;
  wire pc_branch_carry_i_1__2_n_0;
  wire pc_branch_carry_i_1_n_0;
  wire pc_branch_carry_i_2__0_n_0;
  wire pc_branch_carry_i_2__1_n_0;
  wire pc_branch_carry_i_2__2_n_0;
  wire pc_branch_carry_i_2_n_0;
  wire pc_branch_carry_i_3__0_n_0;
  wire pc_branch_carry_i_3__1_n_0;
  wire pc_branch_carry_i_3__2_n_0;
  wire pc_branch_carry_i_3_n_0;
  wire pc_branch_carry_i_4__0_n_0;
  wire pc_branch_carry_i_4__1_n_0;
  wire pc_branch_carry_i_4__2_n_0;
  wire pc_branch_carry_i_4_n_0;
  wire pc_branch_carry_n_0;
  wire pc_branch_carry_n_1;
  wire pc_branch_carry_n_2;
  wire pc_branch_carry_n_3;
  wire [15:0]pc_in;
  wire [15:0]pc_next;
  wire pc_next_carry__0_n_0;
  wire pc_next_carry__0_n_1;
  wire pc_next_carry__0_n_2;
  wire pc_next_carry__0_n_3;
  wire pc_next_carry__1_n_0;
  wire pc_next_carry__1_n_1;
  wire pc_next_carry__1_n_2;
  wire pc_next_carry__1_n_3;
  wire pc_next_carry__2_n_1;
  wire pc_next_carry__2_n_2;
  wire pc_next_carry__2_n_3;
  wire pc_next_carry_i_1_n_0;
  wire pc_next_carry_n_0;
  wire pc_next_carry_n_1;
  wire pc_next_carry_n_2;
  wire pc_next_carry_n_3;
  wire [3:3]NLW_pc_branch_carry__2_CO_UNCONNECTED;
  wire [3:3]NLW_pc_next_carry__2_CO_UNCONNECTED;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_branch_carry
       (.CI(1'b0),
        .CO({pc_branch_carry_n_0,pc_branch_carry_n_1,pc_branch_carry_n_2,pc_branch_carry_n_3}),
        .CYINIT(1'b0),
        .DI(pc_next[3:0]),
        .O(pc_branch[3:0]),
        .S({pc_branch_carry_i_1_n_0,pc_branch_carry_i_2_n_0,pc_branch_carry_i_3_n_0,pc_branch_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_branch_carry__0
       (.CI(pc_branch_carry_n_0),
        .CO({pc_branch_carry__0_n_0,pc_branch_carry__0_n_1,pc_branch_carry__0_n_2,pc_branch_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(pc_next[7:4]),
        .O(pc_branch[7:4]),
        .S({pc_branch_carry_i_1__0_n_0,pc_branch_carry_i_2__0_n_0,pc_branch_carry_i_3__0_n_0,pc_branch_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_branch_carry__1
       (.CI(pc_branch_carry__0_n_0),
        .CO({pc_branch_carry__1_n_0,pc_branch_carry__1_n_1,pc_branch_carry__1_n_2,pc_branch_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(pc_next[11:8]),
        .O(pc_branch[11:8]),
        .S({pc_branch_carry_i_1__1_n_0,pc_branch_carry_i_2__1_n_0,pc_branch_carry_i_3__1_n_0,pc_branch_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_branch_carry__2
       (.CI(pc_branch_carry__1_n_0),
        .CO({NLW_pc_branch_carry__2_CO_UNCONNECTED[3],pc_branch_carry__2_n_1,pc_branch_carry__2_n_2,pc_branch_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,pc_next[14:12]}),
        .O(pc_branch[15:12]),
        .S({pc_branch_carry_i_1__2_n_0,pc_branch_carry_i_2__2_n_0,pc_branch_carry_i_3__2_n_0,pc_branch_carry_i_4__2_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_1
       (.I0(pc_next[3]),
        .I1(imm_shifted[3]),
        .O(pc_branch_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_1__0
       (.I0(pc_next[7]),
        .I1(imm_shifted[7]),
        .O(pc_branch_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_1__1
       (.I0(pc_next[11]),
        .I1(imm_shifted[11]),
        .O(pc_branch_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_1__2
       (.I0(pc_next[15]),
        .I1(imm_shifted[15]),
        .O(pc_branch_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_2
       (.I0(pc_next[2]),
        .I1(imm_shifted[2]),
        .O(pc_branch_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_2__0
       (.I0(pc_next[6]),
        .I1(imm_shifted[6]),
        .O(pc_branch_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_2__1
       (.I0(pc_next[10]),
        .I1(imm_shifted[10]),
        .O(pc_branch_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_2__2
       (.I0(pc_next[14]),
        .I1(imm_shifted[14]),
        .O(pc_branch_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_3
       (.I0(pc_next[1]),
        .I1(imm_shifted[1]),
        .O(pc_branch_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_3__0
       (.I0(pc_next[5]),
        .I1(imm_shifted[5]),
        .O(pc_branch_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_3__1
       (.I0(pc_next[9]),
        .I1(imm_shifted[9]),
        .O(pc_branch_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_3__2
       (.I0(pc_next[13]),
        .I1(imm_shifted[13]),
        .O(pc_branch_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_4
       (.I0(pc_next[0]),
        .I1(imm_shifted[0]),
        .O(pc_branch_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_4__0
       (.I0(pc_next[4]),
        .I1(imm_shifted[4]),
        .O(pc_branch_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_4__1
       (.I0(pc_next[8]),
        .I1(imm_shifted[8]),
        .O(pc_branch_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pc_branch_carry_i_4__2
       (.I0(pc_next[12]),
        .I1(imm_shifted[12]),
        .O(pc_branch_carry_i_4__2_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_next_carry
       (.CI(1'b0),
        .CO({pc_next_carry_n_0,pc_next_carry_n_1,pc_next_carry_n_2,pc_next_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,pc_in[1],1'b0}),
        .O(pc_next[3:0]),
        .S({pc_in[3:2],pc_next_carry_i_1_n_0,pc_in[0]}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_next_carry__0
       (.CI(pc_next_carry_n_0),
        .CO({pc_next_carry__0_n_0,pc_next_carry__0_n_1,pc_next_carry__0_n_2,pc_next_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(pc_next[7:4]),
        .S(pc_in[7:4]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_next_carry__1
       (.CI(pc_next_carry__0_n_0),
        .CO({pc_next_carry__1_n_0,pc_next_carry__1_n_1,pc_next_carry__1_n_2,pc_next_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(pc_next[11:8]),
        .S(pc_in[11:8]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pc_next_carry__2
       (.CI(pc_next_carry__1_n_0),
        .CO({NLW_pc_next_carry__2_CO_UNCONNECTED[3],pc_next_carry__2_n_1,pc_next_carry__2_n_2,pc_next_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(pc_next[15:12]),
        .S(pc_in[15:12]));
  LUT1 #(
    .INIT(2'h1)) 
    pc_next_carry_i_1
       (.I0(pc_in[1]),
        .O(pc_next_carry_i_1_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
