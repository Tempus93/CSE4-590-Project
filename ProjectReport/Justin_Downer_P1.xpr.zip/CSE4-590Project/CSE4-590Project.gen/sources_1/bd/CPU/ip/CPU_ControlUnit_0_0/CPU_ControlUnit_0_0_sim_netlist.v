// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar 24 20:56:25 2026
// Host        : Justin-T480 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/user/CSE4-590Project/CSE4-590Project.gen/sources_1/bd/CPU/ip/CPU_ControlUnit_0_0/CPU_ControlUnit_0_0_sim_netlist.v
// Design      : CPU_ControlUnit_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "CPU_ControlUnit_0_0,ControlUnit,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "ControlUnit,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module CPU_ControlUnit_0_0
   (Instruction,
    RegDst,
    ALUSrc,
    MemtoReg,
    RegWrite,
    MemRead,
    MemWrite,
    Branch,
    BNE,
    Jump,
    ALUOp);
  input [3:0]Instruction;
  output RegDst;
  output ALUSrc;
  output MemtoReg;
  output RegWrite;
  output MemRead;
  output MemWrite;
  output Branch;
  output BNE;
  output Jump;
  output [1:0]ALUOp;

  wire [1:0]ALUOp;
  wire ALUSrc;
  wire BNE;
  wire Branch;
  wire [3:0]Instruction;
  wire Jump;
  wire MemWrite;
  wire MemtoReg;
  wire RegDst;
  wire RegWrite;

  assign MemRead = MemtoReg;
  LUT4 #(
    .INIT(16'h0010)) 
    MemWrite_INST_0
       (.I0(Instruction[2]),
        .I1(Instruction[0]),
        .I2(Instruction[1]),
        .I3(Instruction[3]),
        .O(MemWrite));
  CPU_ControlUnit_0_0_ControlUnit inst
       (.ALUOp(ALUOp),
        .ALUSrc(ALUSrc),
        .BNE(BNE),
        .Branch(Branch),
        .Instruction(Instruction),
        .Jump(Jump),
        .MemtoReg(MemtoReg),
        .RegDst(RegDst),
        .RegWrite(RegWrite));
endmodule

(* ORIG_REF_NAME = "ControlUnit" *) 
module CPU_ControlUnit_0_0_ControlUnit
   (RegDst,
    ALUSrc,
    MemtoReg,
    RegWrite,
    Branch,
    BNE,
    Jump,
    ALUOp,
    Instruction);
  output RegDst;
  output ALUSrc;
  output MemtoReg;
  output RegWrite;
  output Branch;
  output BNE;
  output Jump;
  output [1:0]ALUOp;
  input [3:0]Instruction;

  wire [1:0]ALUOp;
  wire ALUSrc;
  wire BNE;
  wire Branch;
  wire [3:0]Instruction;
  wire Jump;
  wire MemtoReg;
  wire RegDst;
  wire RegWrite;

  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \/i_ 
       (.I0(Instruction[2]),
        .I1(Instruction[0]),
        .I2(Instruction[1]),
        .I3(Instruction[3]),
        .O(RegDst));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0070)) 
    \ALUOp[0]_INST_0 
       (.I0(Instruction[0]),
        .I1(Instruction[1]),
        .I2(Instruction[2]),
        .I3(Instruction[3]),
        .O(ALUOp[0]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0009)) 
    \ALUOp[1]_INST_0 
       (.I0(Instruction[1]),
        .I1(Instruction[2]),
        .I2(Instruction[0]),
        .I3(Instruction[3]),
        .O(ALUOp[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h000E)) 
    \__0/i_ 
       (.I0(Instruction[0]),
        .I1(Instruction[1]),
        .I2(Instruction[2]),
        .I3(Instruction[3]),
        .O(ALUSrc));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    \__1/i_ 
       (.I0(Instruction[1]),
        .I1(Instruction[2]),
        .I2(Instruction[0]),
        .I3(Instruction[3]),
        .O(MemtoReg));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h000D)) 
    \__2/i_ 
       (.I0(Instruction[1]),
        .I1(Instruction[0]),
        .I2(Instruction[2]),
        .I3(Instruction[3]),
        .O(RegWrite));
  LUT3 #(
    .INIT(8'h04)) 
    \__4/i_ 
       (.I0(Instruction[1]),
        .I1(Instruction[2]),
        .I2(Instruction[3]),
        .O(Branch));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0008)) 
    \__5/i_ 
       (.I0(Instruction[2]),
        .I1(Instruction[0]),
        .I2(Instruction[1]),
        .I3(Instruction[3]),
        .O(BNE));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0008)) 
    \__6/i_ 
       (.I0(Instruction[1]),
        .I1(Instruction[2]),
        .I2(Instruction[0]),
        .I3(Instruction[3]),
        .O(Jump));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
