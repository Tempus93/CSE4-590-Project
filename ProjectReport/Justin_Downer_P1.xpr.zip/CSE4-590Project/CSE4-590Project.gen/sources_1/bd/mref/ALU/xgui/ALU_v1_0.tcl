# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "ADD" -parent ${Page_0}
  ipgui::add_param $IPINST -name "AND" -parent ${Page_0}
  ipgui::add_param $IPINST -name "BEQ" -parent ${Page_0}
  ipgui::add_param $IPINST -name "BNE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "JMP" -parent ${Page_0}
  ipgui::add_param $IPINST -name "LW" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SLL" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SUB" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SW" -parent ${Page_0}


}

proc update_PARAM_VALUE.ADD { PARAM_VALUE.ADD } {
	# Procedure called to update ADD when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ADD { PARAM_VALUE.ADD } {
	# Procedure called to validate ADD
	return true
}

proc update_PARAM_VALUE.AND { PARAM_VALUE.AND } {
	# Procedure called to update AND when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AND { PARAM_VALUE.AND } {
	# Procedure called to validate AND
	return true
}

proc update_PARAM_VALUE.BEQ { PARAM_VALUE.BEQ } {
	# Procedure called to update BEQ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BEQ { PARAM_VALUE.BEQ } {
	# Procedure called to validate BEQ
	return true
}

proc update_PARAM_VALUE.BNE { PARAM_VALUE.BNE } {
	# Procedure called to update BNE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BNE { PARAM_VALUE.BNE } {
	# Procedure called to validate BNE
	return true
}

proc update_PARAM_VALUE.JMP { PARAM_VALUE.JMP } {
	# Procedure called to update JMP when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.JMP { PARAM_VALUE.JMP } {
	# Procedure called to validate JMP
	return true
}

proc update_PARAM_VALUE.LW { PARAM_VALUE.LW } {
	# Procedure called to update LW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LW { PARAM_VALUE.LW } {
	# Procedure called to validate LW
	return true
}

proc update_PARAM_VALUE.SLL { PARAM_VALUE.SLL } {
	# Procedure called to update SLL when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SLL { PARAM_VALUE.SLL } {
	# Procedure called to validate SLL
	return true
}

proc update_PARAM_VALUE.SUB { PARAM_VALUE.SUB } {
	# Procedure called to update SUB when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SUB { PARAM_VALUE.SUB } {
	# Procedure called to validate SUB
	return true
}

proc update_PARAM_VALUE.SW { PARAM_VALUE.SW } {
	# Procedure called to update SW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SW { PARAM_VALUE.SW } {
	# Procedure called to validate SW
	return true
}


proc update_MODELPARAM_VALUE.ADD { MODELPARAM_VALUE.ADD PARAM_VALUE.ADD } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ADD}] ${MODELPARAM_VALUE.ADD}
}

proc update_MODELPARAM_VALUE.SUB { MODELPARAM_VALUE.SUB PARAM_VALUE.SUB } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SUB}] ${MODELPARAM_VALUE.SUB}
}

proc update_MODELPARAM_VALUE.SLL { MODELPARAM_VALUE.SLL PARAM_VALUE.SLL } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SLL}] ${MODELPARAM_VALUE.SLL}
}

proc update_MODELPARAM_VALUE.AND { MODELPARAM_VALUE.AND PARAM_VALUE.AND } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AND}] ${MODELPARAM_VALUE.AND}
}

proc update_MODELPARAM_VALUE.LW { MODELPARAM_VALUE.LW PARAM_VALUE.LW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LW}] ${MODELPARAM_VALUE.LW}
}

proc update_MODELPARAM_VALUE.SW { MODELPARAM_VALUE.SW PARAM_VALUE.SW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SW}] ${MODELPARAM_VALUE.SW}
}

proc update_MODELPARAM_VALUE.BEQ { MODELPARAM_VALUE.BEQ PARAM_VALUE.BEQ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BEQ}] ${MODELPARAM_VALUE.BEQ}
}

proc update_MODELPARAM_VALUE.BNE { MODELPARAM_VALUE.BNE PARAM_VALUE.BNE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BNE}] ${MODELPARAM_VALUE.BNE}
}

proc update_MODELPARAM_VALUE.JMP { MODELPARAM_VALUE.JMP PARAM_VALUE.JMP } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.JMP}] ${MODELPARAM_VALUE.JMP}
}

