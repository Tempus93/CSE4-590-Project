vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/xlslice_v1_0_5

vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap xlslice_v1_0_5 modelsim_lib/msim/xlslice_v1_0_5

vlog -work xil_defaultlib  -incr -mfcu  "+incdir+../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" \
"../../../bd/CPU/ip/CPU_ALU_0_0/sim/CPU_ALU_0_0.v" \
"../../../bd/CPU/ip/CPU_ControlUnit_0_0/sim/CPU_ControlUnit_0_0.v" \
"../../../bd/CPU/ip/CPU_PCRegister_0_0/sim/CPU_PCRegister_0_0.v" \
"../../../bd/CPU/ip/CPU_InstructMem_0_0/sim/CPU_InstructMem_0_0.v" \
"../../../bd/CPU/ip/CPU_SignExt_0_0/sim/CPU_SignExt_0_0.v" \
"../../../bd/CPU/ip/CPU_RegisterFile_0_0/sim/CPU_RegisterFile_0_0.v" \
"../../../bd/CPU/ip/CPU_Multiplexer_1_0/sim/CPU_Multiplexer_1_0.v" \
"../../../bd/CPU/ip/CPU_DataMemory_1_0/sim/CPU_DataMemory_1_0.v" \
"../../../bd/CPU/ip/CPU_Multiplexer_2_0/sim/CPU_Multiplexer_2_0.v" \
"../../../bd/CPU/ip/CPU_PCAdder_0_0/sim/CPU_PCAdder_0_0.v" \
"../../../bd/CPU/ip/CPU_ANDGate_0_0/sim/CPU_ANDGate_0_0.v" \
"../../../bd/CPU/ip/CPU_Multiplexer_3_0/sim/CPU_Multiplexer_3_0.v" \
"../../../bd/CPU/ip/CPU_PCAdder_1_0/sim/CPU_PCAdder_1_0.v" \
"../../../bd/CPU/ip/CPU_ShiftLeft2v2_0_0/sim/CPU_ShiftLeft2v2_0_0.v" \
"../../../bd/CPU/ip/CPU_Multiplexer_3_1/sim/CPU_Multiplexer_3_1.v" \
"../../../bd/CPU/ip/CPU_XORGate_0_0/sim/CPU_XORGate_0_0.v" \

vlog -work xlslice_v1_0_5  -incr -mfcu  "+incdir+../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" \
"../../../../CSE4-590Project.gen/sources_1/bd/CPU/ipshared/6792/hdl/xlslice_v1_0_vl_rfs.v" \

vlog -work xil_defaultlib  -incr -mfcu  "+incdir+../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" \
"../../../bd/CPU/ip/CPU_xlslice_0_1/sim/CPU_xlslice_0_1.v" \
"../../../bd/CPU/ip/CPU_xlslice_1_0/sim/CPU_xlslice_1_0.v" \
"../../../bd/CPU/ip/CPU_xlslice_2_0/sim/CPU_xlslice_2_0.v" \
"../../../bd/CPU/ip/CPU_xlslice_3_0/sim/CPU_xlslice_3_0.v" \
"../../../bd/CPU/ip/CPU_xlslice_0_4/sim/CPU_xlslice_0_4.v" \
"../../../bd/CPU/ip/CPU_fourbitMux_0_0/sim/CPU_fourbitMux_0_0.v" \
"../../../bd/CPU/ip/CPU_ALUControl_0_1/sim/CPU_ALUControl_0_1.v" \
"../../../bd/CPU/ip/CPU_ShiftLeft1_0_0/sim/CPU_ShiftLeft1_0_0.v" \
"../../../bd/CPU/ip/CPU_xlslice_0_5/sim/CPU_xlslice_0_5.v" \
"../../../bd/CPU/ip/CPU_SignExt11Jump_0_0/sim/CPU_SignExt11Jump_0_0.v" \
"../../../bd/CPU/sim/CPU.v" \
"../../../bd/CPU/ip/CPU_PCAdder_0_1/sim/CPU_PCAdder_0_1.v" \

vlog -work xil_defaultlib \
"glbl.v"

