vopt -l elaborate.log +acc=npr -suppress 10016  -L xil_defaultlib -L xlslice_v1_0_5 -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.CPU xil_defaultlib.glbl -o CPU_opt
